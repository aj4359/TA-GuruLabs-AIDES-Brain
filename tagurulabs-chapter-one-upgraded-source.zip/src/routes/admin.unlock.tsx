import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { unlockAdmin } from "@/lib/admin.functions";

export const Route = createFileRoute("/admin/unlock")({
  component: Unlock,
  head: () => ({ meta: [{ title: "Admin · Unlock" }, { name: "robots", content: "noindex" }] }),
});

function Unlock() {
  const router = useRouter();
  const unlock = useServerFn(unlockAdmin);
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setError(false);
    const password = new FormData(e.currentTarget).get("password") as string;
    const { ok } = await unlock({ data: { password } });
    setLoading(false);
    if (ok) await router.navigate({ to: "/admin" });
    else setError(true);
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <form
        onSubmit={onSubmit}
        className="w-full max-w-sm space-y-4 rounded-lg border border-border bg-card p-6"
      >
        <div>
          <h1 className="text-lg font-semibold text-foreground">Admin access</h1>
          <p className="mt-1 text-sm text-muted-foreground">Enter the admin password to continue.</p>
        </div>
        <input
          name="password"
          type="password"
          autoComplete="current-password"
          autoFocus
          required
          className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground outline-none focus:ring-2 focus:ring-primary"
        />
        {error && <p className="text-sm text-destructive">Incorrect password</p>}
        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-50"
        >
          {loading ? "Unlocking…" : "Enter"}
        </button>
      </form>
    </div>
  );
}