import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { getAdminDashboard, lockAdmin, type DashboardData } from "@/lib/admin.functions";

export const Route = createFileRoute("/admin")({
  loader: () => getAdminDashboard(),
  component: Admin,
  head: () => ({ meta: [{ title: "Admin · Dashboard" }, { name: "robots", content: "noindex" }] }),
  errorComponent: ({ error }) => (
    <div className="p-8 text-sm text-destructive">Failed to load: {error.message}</div>
  ),
});

function Admin() {
  const data = Route.useLoaderData() as DashboardData;
  const router = useRouter();
  const lock = useServerFn(lockAdmin);

  async function onLock() {
    await lock();
    await router.navigate({ to: "/admin/unlock" });
  }

  const maxFunnel = Math.max(1, ...data.funnel.map((f) => f.count));
  const maxScene = Math.max(1, ...data.scenes.map((s) => s.views));

  return (
    <div className="min-h-screen bg-background px-6 py-10 text-foreground">
      <div className="mx-auto max-w-5xl space-y-8">
        <header className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold">Admin dashboard</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Viewer funnel & access requests
            </p>
          </div>
          <button
            onClick={onLock}
            className="rounded-md border border-border px-3 py-1.5 text-xs text-muted-foreground hover:text-foreground"
          >
            Lock
          </button>
        </header>

        <section className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          <Stat label="Sessions" value={data.totalSessions} />
          <Stat
            label="Completions"
            value={data.funnel.find((f) => f.event_type === "complete")?.count ?? 0}
          />
          <Stat
            label="Shares"
            value={data.funnel.find((f) => f.event_type === "share")?.count ?? 0}
          />
          <Stat label="Access requests" value={data.accessCount} />
        </section>

        <section className="rounded-lg border border-border bg-card p-6">
          <h2 className="mb-4 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Event funnel
          </h2>
          {data.funnel.length === 0 ? (
            <p className="text-sm text-muted-foreground">No events yet.</p>
          ) : (
            <ul className="space-y-2">
              {data.funnel.map((f) => (
                <li key={f.event_type} className="grid grid-cols-[8rem_1fr_3rem] items-center gap-3">
                  <span className="text-sm text-foreground">{f.event_type}</span>
                  <div className="h-2 overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full rounded-full bg-primary"
                      style={{ width: `${(f.count / maxFunnel) * 100}%` }}
                    />
                  </div>
                  <span className="text-right text-sm tabular-nums text-muted-foreground">
                    {f.count}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="rounded-lg border border-border bg-card p-6">
          <h2 className="mb-4 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Scene drop-off
          </h2>
          {data.scenes.length === 0 ? (
            <p className="text-sm text-muted-foreground">No scene views yet.</p>
          ) : (
            <ul className="space-y-2">
              {data.scenes.map((s) => (
                <li key={s.scene_id} className="grid grid-cols-[8rem_1fr_3rem] items-center gap-3">
                  <span className="text-sm text-foreground">Scene {s.scene_id}</span>
                  <div className="h-2 overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full rounded-full bg-primary/70"
                      style={{ width: `${(s.views / maxScene) * 100}%` }}
                    />
                  </div>
                  <span className="text-right text-sm tabular-nums text-muted-foreground">
                    {s.views}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="rounded-lg border border-border bg-card p-6">
          <h2 className="mb-4 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Access requests ({data.accessCount})
          </h2>
          {data.accessRequests.length === 0 ? (
            <p className="text-sm text-muted-foreground">No requests yet.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border text-left text-xs uppercase tracking-wide text-muted-foreground">
                    <th className="py-2 pr-4">Email</th>
                    <th className="py-2 pr-4">Source</th>
                    <th className="py-2">When</th>
                  </tr>
                </thead>
                <tbody>
                  {data.accessRequests.map((r) => (
                    <tr key={r.id} className="border-b border-border/50">
                      <td className="py-2 pr-4 text-foreground">{r.email}</td>
                      <td className="py-2 pr-4 text-muted-foreground">{r.source ?? "—"}</td>
                      <td className="py-2 text-muted-foreground">
                        {new Date(r.created_at).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <div className="text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="mt-1 text-2xl font-semibold tabular-nums text-foreground">{value}</div>
    </div>
  );
}