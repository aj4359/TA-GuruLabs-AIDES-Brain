import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { getProphecyById } from "@/lib/prophecy-read.functions";
import { getRequestOrigin } from "@/lib/origin.functions";
import { speakProphecy, type TtsHandle } from "@/lib/tts";

export const Route = createFileRoute("/scroll/$id")({
  loader: async ({ params }) => {
    const [row, origin] = await Promise.all([
      getProphecyById({ data: { id: params.id } }),
      getRequestOrigin(),
    ]);
    if (!row) throw notFound();
    return { row, origin };
  },
  head: ({ loaderData, params }) => {
    const row = loaderData?.row;
    const origin = loaderData?.origin ?? "";
    const handle = row?.handle ?? "traveller";
    const title = `A prophecy for ${handle} — TA GuruLabs`;
    const description =
      row?.prophecy?.replace(/\n/g, " · ").slice(0, 200) ??
      "A cinematic oracle prophecy from the TA GuruLabs portal.";
    const url = `${origin}/scroll/${params?.id ?? ""}`;
    const posterPath = `/api/scroll/${params?.id ?? ""}/poster`;
    const absoluteOg = origin ? `${origin}${posterPath}` : posterPath;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "article" },
        { property: "og:url", content: url },
        { property: "og:image", content: absoluteOg },
        { property: "og:image:width", content: "1536" },
        { property: "og:image:height", content: "1024" },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:title", content: title },
        { name: "twitter:description", content: description },
        { name: "twitter:image", content: absoluteOg },
      ],
      links: [{ rel: "canonical", href: url }],
    };
  },
  notFoundComponent: () => (
    <div className="flex min-h-screen items-center justify-center bg-[#04050a] px-4 text-white">
      <div className="text-center">
        <div
          className="font-mono text-[10px] uppercase tracking-[0.5em]"
          style={{ color: "#d4af5a" }}
        >
          scroll unreadable
        </div>
        <h1 className="mt-4 text-2xl">The prophecy has faded.</h1>
        <Link to="/" className="mt-6 inline-block text-sm text-white/60 underline">
          Return to the portal
        </Link>
      </div>
    </div>
  ),
  component: Scroll,
});

function Scroll() {
  const { row } = Route.useLoaderData();
  const params = Route.useParams();
  const [speaking, setSpeaking] = useState(false);
  const [copied, setCopied] = useState(false);
  const [recording, setRecording] = useState(false);
  const [oracleBusy, setOracleBusy] = useState(false);
  const [oracleTranscript, setOracleTranscript] = useState<string | null>(null);
  const [oracleReply, setOracleReply] = useState<string | null>(null);
  const [oracleError, setOracleError] = useState<string | null>(null);
  const [posterLoaded, setPosterLoaded] = useState(false);
  const handleRef = useRef<TtsHandle | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    return () => {
      handleRef.current?.stop();
      streamRef.current?.getTracks().forEach((t) => t.stop());
    };
  }, []);

  const speak = (text?: string) => {
    const toSay = text ?? row.prophecy;
    if (speaking) {
      handleRef.current?.stop();
      setSpeaking(false);
      return;
    }
    setSpeaking(true);
    const h = speakProphecy(toSay);
    handleRef.current = h;
    h.done.finally(() => setSpeaking(false));
  };

  const share = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch { /* noop */ }
  };

  const startRecording = async () => {
    setOracleError(null);
    setOracleTranscript(null);
    setOracleReply(null);
    if (speaking) {
      handleRef.current?.stop();
      setSpeaking(false);
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const mime = MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
        ? "audio/webm;codecs=opus"
        : MediaRecorder.isTypeSupported("audio/mp4")
        ? "audio/mp4"
        : "";
      const rec = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
      chunksRef.current = [];
      rec.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) chunksRef.current.push(e.data);
      };
      rec.onstop = () => {
        void sendRecording(rec.mimeType || "audio/webm");
        streamRef.current?.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
      };
      recorderRef.current = rec;
      rec.start();
      setRecording(true);
    } catch (err) {
      console.error("mic denied", err);
      setOracleError("Microphone access is required.");
    }
  };

  const stopRecording = () => {
    const rec = recorderRef.current;
    if (!rec) return;
    setRecording(false);
    setOracleBusy(true);
    try {
      rec.stop();
    } catch { /* noop */ }
  };

  const sendRecording = async (mime: string) => {
    try {
      const blob = new Blob(chunksRef.current, { type: mime });
      chunksRef.current = [];
      if (blob.size < 2048) {
        setOracleError("Speak a little longer.");
        setOracleBusy(false);
        return;
      }
      const ext = mime.includes("mp4") ? "mp4" : mime.includes("ogg") ? "ogg" : "webm";
      const fd = new FormData();
      fd.append("audio", blob, `recording.${ext}`);
      fd.append("prophecy", row.prophecy);
      fd.append("handle", row.handle ?? "traveller");
      const res = await fetch("/api/oracle", { method: "POST", body: fd });
      if (!res.ok) {
        const t = await res.text().catch(() => "");
        setOracleError(t || "The oracle could not hear you.");
        setOracleBusy(false);
        return;
      }
      const j = (await res.json()) as { transcript?: string; reply?: string };
      setOracleTranscript(j.transcript ?? "");
      setOracleReply(j.reply ?? "");
      setOracleBusy(false);
      if (j.reply) speak(j.reply);
    } catch (err) {
      console.error("oracle send failed", err);
      setOracleError("The signal broke.");
      setOracleBusy(false);
    }
  };

  const posterSrc = `/api/scroll/${params.id}/poster`;

  return (
    <div
      className="relative flex min-h-screen w-full items-center justify-center overflow-hidden px-4 py-16"
      style={{ background: "#04050a", color: "#e6e2d3" }}
    >
      <div className="pointer-events-none absolute inset-0 -z-0">
        <div
          className="absolute -inset-[20%]"
          style={{
            background:
              "radial-gradient(ellipse 60% 50% at 30% 40%, rgba(212,175,90,0.22), transparent 60%), radial-gradient(ellipse 55% 45% at 70% 65%, rgba(75,184,255,0.12), transparent 60%), radial-gradient(ellipse 50% 40% at 50% 100%, rgba(160,107,255,0.16), transparent 60%)",
            animation: "ta-aurora 24s ease-in-out infinite",
            filter: "blur(40px)",
          }}
        />
      </div>

      <div className="relative z-10 mx-auto max-w-2xl text-center">
        <div
          className="font-mono text-[10px] uppercase tracking-[0.5em]"
          style={{ color: "#d4af5a" }}
        >
          · Oracle Transmission · for {row.handle ?? "traveller"} ·
        </div>

        <div
          className="relative mx-auto mt-6 aspect-[3/2] w-full max-w-xl overflow-hidden rounded-lg border"
          style={{
            borderColor: "#d4af5a55",
            boxShadow: "0 40px 120px -30px rgba(212,175,90,0.35)",
          }}
        >
          {!posterLoaded && (
            <div
              className="absolute inset-0 flex items-center justify-center"
              style={{
                background:
                  "radial-gradient(circle at 50% 50%, rgba(212,175,90,0.25), rgba(4,5,10,0.9))",
              }}
            >
              <div
                className="font-mono text-[9px] uppercase tracking-[0.4em]"
                style={{ color: "#d4af5a" }}
              >
                forging sigil…
              </div>
            </div>
          )}
          <img
            src={posterSrc}
            alt={`Vibranium sigil for ${row.handle ?? "traveller"}`}
            onLoad={() => setPosterLoaded(true)}
            className="h-full w-full object-cover transition-opacity duration-700"
            style={{ opacity: posterLoaded ? 1 : 0 }}
          />
        </div>

        <div
          className="mt-8 rounded-lg border p-8 md:p-12"
          style={{
            borderColor: "#d4af5a55",
            background: "linear-gradient(180deg, rgba(212,175,90,0.06), rgba(4,5,10,0.6))",
            boxShadow:
              "0 0 80px -20px rgba(212,175,90,0.5) inset, 0 40px 120px -30px rgba(212,175,90,0.25)",
          }}
        >
          <p
            className="whitespace-pre-line text-lg leading-relaxed md:text-2xl"
            style={{
              color: "#f5efd7",
              fontFamily: "'Space Grotesk', system-ui, sans-serif",
              letterSpacing: "0.02em",
              textShadow: "0 0 40px rgba(212,175,90,0.35)",
            }}
          >
            {row.prophecy}
          </p>
        </div>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={() => speak()}
            className="inline-flex items-center gap-2 rounded-md px-5 py-2.5 text-[11px] uppercase tracking-[0.3em] transition-all duration-200 active:scale-[0.97]"
            style={{ background: "#d4af5a", color: "#05070d" }}
          >
            {speaking ? "Silence the oracle" : "Hear the oracle"}
          </button>
          <button
            onClick={share}
            className="inline-flex items-center gap-2 rounded-md border border-white/20 bg-white/[0.03] px-5 py-2.5 text-[11px] uppercase tracking-[0.3em] text-white/80 hover:bg-white/[0.08] active:scale-[0.97]"
          >
            {copied ? "Link copied" : "Share this scroll"}
          </button>
          <Link
            to="/"
            className="inline-flex items-center gap-2 rounded-md border border-white/10 px-5 py-2.5 text-[11px] uppercase tracking-[0.3em] text-white/60 hover:text-white"
          >
            Enter the portal
          </Link>
        </div>

        {/* Live oracle conversation */}
        <div className="mt-10 border-t pt-8" style={{ borderColor: "#d4af5a22" }}>
          <div
            className="font-mono text-[10px] uppercase tracking-[0.5em]"
            style={{ color: "#d4af5a" }}
          >
            · Speak to the oracle ·
          </div>
          <p className="mt-3 text-xs text-white/50">
            Hold to speak. Release to hear the oracle answer.
          </p>
          <div className="mt-5 flex flex-col items-center gap-4">
            <button
              type="button"
              disabled={oracleBusy}
              onMouseDown={startRecording}
              onMouseUp={stopRecording}
              onMouseLeave={() => recording && stopRecording()}
              onTouchStart={(e) => { e.preventDefault(); void startRecording(); }}
              onTouchEnd={(e) => { e.preventDefault(); stopRecording(); }}
              className="relative inline-flex h-20 w-20 items-center justify-center rounded-full transition-transform duration-150 active:scale-95 disabled:opacity-60"
              style={{
                background: recording
                  ? "radial-gradient(circle at 50% 50%, #ff5a4b, #7a1512 70%)"
                  : "radial-gradient(circle at 50% 50%, #d4af5a, #6b4a10 70%)",
                boxShadow: recording
                  ? "0 0 60px 6px rgba(255,90,75,0.6), inset 0 0 30px rgba(0,0,0,0.4)"
                  : "0 0 40px 4px rgba(212,175,90,0.4), inset 0 0 20px rgba(0,0,0,0.4)",
              }}
              aria-label={recording ? "Release to send" : "Hold to speak"}
            >
              <span
                className="font-mono text-[9px] uppercase tracking-[0.3em]"
                style={{ color: "#05070d" }}
              >
                {oracleBusy ? "…" : recording ? "REL" : "HOLD"}
              </span>
              {recording && (
                <span
                  className="absolute inset-0 rounded-full"
                  style={{
                    boxShadow: "0 0 0 0 rgba(255,90,75,0.5)",
                    animation: "ta-oracle-pulse 1.2s ease-out infinite",
                  }}
                />
              )}
            </button>

            {oracleError && (
              <div className="text-xs" style={{ color: "#ff9b8a" }}>
                {oracleError}
              </div>
            )}
            {oracleTranscript && (
              <div className="max-w-lg text-xs italic text-white/50">
                you said: “{oracleTranscript}”
              </div>
            )}
            {oracleReply && (
              <div
                className="max-w-lg whitespace-pre-line rounded-md border p-4 text-base leading-relaxed"
                style={{
                  borderColor: "#d4af5a55",
                  background: "rgba(212,175,90,0.05)",
                  color: "#f5efd7",
                  fontFamily: "'Space Grotesk', system-ui, sans-serif",
                  textShadow: "0 0 30px rgba(212,175,90,0.3)",
                }}
              >
                {oracleReply}
              </div>
            )}
          </div>
        </div>
      </div>
      <style>{`@keyframes ta-oracle-pulse { 0% { box-shadow: 0 0 0 0 rgba(255,90,75,0.5); } 100% { box-shadow: 0 0 0 24px rgba(255,90,75,0); } }`}</style>
    </div>
  );
}