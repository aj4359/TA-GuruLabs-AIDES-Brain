import { createFileRoute } from "@tanstack/react-router";

// SSE proxy to Lovable AI Gateway TTS. Streams PCM (24kHz s16le mono) chunks
// so the client can play audio as it's generated.
export const Route = createFileRoute("/api/tts")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("AI unavailable", { status: 503 });

        let body: { text?: unknown; voice?: unknown };
        try {
          body = (await request.json()) as { text?: unknown; voice?: unknown };
        } catch {
          return new Response("Bad JSON", { status: 400 });
        }
        const text = typeof body.text === "string" ? body.text.slice(0, 2000) : "";
        if (!text.trim()) return new Response("Missing text", { status: 400 });
        const voice = typeof body.voice === "string" ? body.voice : "sage";

        try {
          const upstream = await fetch(
            "https://ai.gateway.lovable.dev/v1/audio/speech",
            {
              method: "POST",
              headers: {
                Authorization: `Bearer ${key}`,
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                model: "openai/gpt-4o-mini-tts",
                input: text,
                voice,
                stream_format: "sse",
                response_format: "pcm",
                instructions:
                  "Deep, slow, resonant oracle voice. Cinematic, unhurried, reverent. Slight solemn weight on each phrase.",
                speed: 0.92,
              }),
              signal: request.signal,
            },
          );

          if (!upstream.ok || !upstream.body) {
            const errText = await upstream.text().catch(() => "");
            console.error("tts upstream failed", upstream.status, errText.slice(0, 300));
            return new Response(errText || "TTS failed", { status: upstream.status });
          }

          return new Response(upstream.body, {
            headers: {
              "Content-Type": "text/event-stream",
              "Cache-Control": "no-cache, no-transform",
            },
          });
        } catch (err) {
          if (request.signal.aborted) return new Response(null, { status: 499 });
          console.error("tts fetch threw", err);
          return new Response("TTS error", { status: 500 });
        }
      },
    },
  },
});