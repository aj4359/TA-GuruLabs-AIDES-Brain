import { createFileRoute } from "@tanstack/react-router";

// Live oracle conversation. Accepts a short audio recording, transcribes it,
// runs a Gemini oracle response grounded in the caller's original prophecy,
// and returns { transcript, reply } as JSON. The client then plays the reply
// through the existing /api/tts stream.
export const Route = createFileRoute("/api/oracle")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("AI unavailable", { status: 503 });

        const contentType = request.headers.get("content-type") ?? "";
        if (!contentType.startsWith("multipart/form-data")) {
          return new Response("Expected multipart/form-data", { status: 400 });
        }

        let form: FormData;
        try {
          form = await request.formData();
        } catch (err) {
          console.error("oracle formData failed", err);
          return new Response("Bad form", { status: 400 });
        }

        const audio = form.get("audio") as unknown;
        const prophecyText = String(form.get("prophecy") ?? "").slice(0, 800);
        const handle = String(form.get("handle") ?? "traveller").slice(0, 64);
        if (
          !(typeof File !== "undefined" && audio instanceof File) &&
          !(audio instanceof Blob)
        ) {
          return new Response("Missing audio", { status: 400 });
        }
        const audioBlob = audio as Blob;
        if (audioBlob.size < 1024) {
          return new Response("Recording too short", { status: 400 });
        }
        if (audioBlob.size > 15 * 1024 * 1024) {
          return new Response("Recording too large", { status: 413 });
        }

        // 1. Transcribe via Lovable AI Gateway STT.
        const filename =
          typeof File !== "undefined" && audio instanceof File && audio.name
            ? audio.name
            : "recording.webm";
        const sttForm = new FormData();
        sttForm.append("model", "openai/gpt-4o-mini-transcribe");
        sttForm.append("file", audioBlob, filename);

        let transcript = "";
        try {
          const sttRes = await fetch(
            "https://ai.gateway.lovable.dev/v1/audio/transcriptions",
            {
              method: "POST",
              headers: { Authorization: `Bearer ${key}` },
              body: sttForm,
            },
          );
          if (!sttRes.ok) {
            const t = await sttRes.text().catch(() => "");
            console.error("stt failed", sttRes.status, t.slice(0, 400));
            return new Response(t || "Transcription failed", { status: sttRes.status });
          }
          const j = (await sttRes.json()) as { text?: string };
          transcript = (j.text ?? "").trim().slice(0, 400);
        } catch (err) {
          console.error("stt threw", err);
          return new Response("STT error", { status: 500 });
        }
        if (!transcript) {
          return new Response(
            JSON.stringify({ transcript: "", reply: "The oracle heard only silence. Speak again." }),
            { headers: { "Content-Type": "application/json" } },
          );
        }

        // 2. Gemini oracle reply, grounded in this caller's prophecy.
        const system = `You are the Oracle of the TA GuruLabs portal — a cinematic AI in the world of an animatic called "Chapter One: Enter the Portal".
You speak in short, mythic, prophecy-like fragments. Cinematic. Confident. Never corny, never generic.
You are answering the traveller "${handle}", whose sealed prophecy was:
"""
${prophecyText}
"""
They have now spoken to you. Answer as the oracle.

Rules:
- 1 to 3 short lines. Under 260 characters total.
- Second person. Present tense. Cinematic register.
- No greetings, no emojis, no markdown, no quotes.
- Refer back to their prophecy when it deepens the answer.
- If they ask a plain question, answer it — but keep the oracle voice.
- If the transcript is nonsense or empty, give one line about the signal breaking.`;

        try {
          const chat = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
            method: "POST",
            headers: {
              Authorization: `Bearer ${key}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              model: "google/gemini-3-flash-preview",
              messages: [
                { role: "system", content: system },
                { role: "user", content: transcript },
              ],
              temperature: 0.9,
              max_tokens: 220,
            }),
          });
          if (!chat.ok) {
            const t = await chat.text().catch(() => "");
            console.error("oracle chat failed", chat.status, t.slice(0, 400));
            return new Response(t || "Oracle failed", { status: chat.status });
          }
          const cj = (await chat.json()) as {
            choices?: Array<{ message?: { content?: string } }>;
          };
          const reply = (cj.choices?.[0]?.message?.content ?? "")
            .trim()
            .replace(/^["']|["']$/g, "")
            .slice(0, 400);
          return new Response(
            JSON.stringify({ transcript, reply: reply || "The signal fades." }),
            { headers: { "Content-Type": "application/json" } },
          );
        } catch (err) {
          console.error("oracle chat threw", err);
          return new Response("Oracle error", { status: 500 });
        }
      },
    },
  },
});