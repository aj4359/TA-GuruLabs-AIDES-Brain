import { createFileRoute } from "@tanstack/react-router";

// Public poster endpoint. Serves a cached 1536x1024 AI-generated poster for a
// given prophecy. On first request it generates + persists the poster; later
// requests (social scrapers, subsequent views) serve the cached bytes.
export const Route = createFileRoute("/api/scroll/$id/poster")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const id = params.id;
        if (!/^[0-9a-f-]{36}$/i.test(id)) {
          return new Response("Bad id", { status: 400 });
        }
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        const { data: row, error } = await supabaseAdmin
          .from("prophecies")
          .select("prophecy, handle, poster_bytes, poster_content_type")
          .eq("id", id)
          .maybeSingle();
        if (error || !row) return new Response("Not found", { status: 404 });

        // Cache hit — decode base64 (PostgREST returns bytea as base64) and stream.
        if (row.poster_bytes) {
          const bytes = base64ToBytes(row.poster_bytes);
          return new Response(new Blob([bytes.buffer as ArrayBuffer]), {
            headers: {
              "Content-Type": row.poster_content_type ?? "image/png",
              "Cache-Control": "public, max-age=31536000, immutable",
            },
          });
        }

        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("AI unavailable", { status: 503 });

        const prophecy = row.prophecy ?? "";
        const handle = row.handle ?? "traveller";

        // Cinematic Afrofuturist poster prompt. We intentionally do NOT ask the
        // model to render the prophecy text — image models garble long text.
        // The prophecy itself is rendered by the /scroll/$id UI; the poster is
        // the atmospheric artwork that draws people to the link.
        const prompt = [
          "A cinematic Afrofuturist movie poster.",
          "Wakandan aesthetic: a single glowing vibranium sigil at center — an intricate geometric emblem of interlocking rings, hexagons, and tribal glyphs — cast in molten gold and deep purple light against obsidian black.",
          "Behind it: swirling nebula of violet, gold, and cool teal energy, faint circuit filigree, subtle particulate light rays.",
          `The sigil is unique and personal to a traveller named "${handle}".`,
          "Mood: mythic, reverent, prophecy, oracle, ceremonial, IMAX-scale.",
          "Composition: symmetrical, ultra-detailed, dramatic rim lighting, deep blacks, cinematic 2.35:1 framing.",
          "No text. No letters. No words. No watermark.",
          `Emotional tone hint (do not render as text): ${prophecy.replace(/\n/g, " ").slice(0, 160)}`,
        ].join(" ");

        try {
          const res = await fetch("https://ai.gateway.lovable.dev/v1/images/generations", {
            method: "POST",
            headers: {
              Authorization: `Bearer ${key}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              model: "openai/gpt-image-1-mini",
              prompt,
              size: "1536x1024",
              n: 1,
            }),
          });
          if (!res.ok) {
            const t = await res.text().catch(() => "");
            console.error("poster gen failed", res.status, t.slice(0, 400));
            return new Response("Poster generation failed", { status: 502 });
          }
          const json = (await res.json()) as {
            data?: Array<{ b64_json?: string; url?: string }>;
          };
          const b64 = json.data?.[0]?.b64_json;
          let bytes: Uint8Array | null = null;
          let contentType = "image/png";
          if (b64) {
            bytes = base64ToBytes(b64);
          } else if (json.data?.[0]?.url) {
            const imgRes = await fetch(json.data[0].url);
            if (imgRes.ok) {
              const ab = await imgRes.arrayBuffer();
              bytes = new Uint8Array(ab);
              contentType = imgRes.headers.get("content-type") ?? "image/png";
            }
          }
          if (!bytes) return new Response("Poster empty", { status: 502 });

          // Persist for future hits. Store as base64 in bytea column.
          const b64Store = bytes ? bytesToBase64(bytes) : null;
          if (b64Store) {
            await supabaseAdmin
              .from("prophecies")
              .update({ poster_bytes: b64Store, poster_content_type: contentType })
              .eq("id", id);
          }

          return new Response(new Blob([bytes.buffer as ArrayBuffer]), {
            headers: {
              "Content-Type": contentType,
              "Cache-Control": "public, max-age=31536000, immutable",
            },
          });
        } catch (err) {
          console.error("poster fetch threw", err);
          return new Response("Poster error", { status: 500 });
        }
      },
    },
  },
});

function base64ToBytes(b64: string): Uint8Array {
  // Handles PostgREST bytea format that may be prefixed with "\\x" (hex) — try base64 first.
  const clean = b64.startsWith("\\x") ? "" : b64;
  if (b64.startsWith("\\x")) {
    const hex = b64.slice(2);
    const out = new Uint8Array(hex.length / 2);
    for (let i = 0; i < out.length; i++) out[i] = parseInt(hex.substr(i * 2, 2), 16);
    return out;
  }
  const bin = atob(clean);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

function bytesToBase64(bytes: Uint8Array): string {
  let bin = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    bin += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(bin);
}