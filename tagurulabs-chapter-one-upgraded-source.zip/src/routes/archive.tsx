import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import soundtrackAsset from "@/assets/soundtrack.png.asset.json";
import storyboardAsset from "@/assets/storyboard.png.asset.json";

export const Route = createFileRoute("/archive")({
  head: () => ({
    meta: [
      { title: "The Archive — TA GuruLabs Chapter One" },
      {
        name: "description",
        content:
          "The storyboard and soundtrack blueprint behind Chapter One: Enter the Portal.",
      },
      { property: "og:title", content: "The Archive — Chapter One" },
      {
        property: "og:description",
        content: "Storyboard + soundtrack blueprint. Built by AIDES. Led by vision.",
      },
      { property: "og:type", content: "article" },
      { property: "og:image", content: storyboardAsset.url },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:image", content: storyboardAsset.url },
    ],
  }),
  component: ArchivePage,
});

type Panel = {
  id: "storyboard" | "soundtrack";
  kicker: string;
  title: string;
  caption: string;
  url: string;
};

const PANELS: Panel[] = [
  {
    id: "storyboard",
    kicker: "I · STORYBOARD",
    title: "Twelve frames. One arc.",
    caption:
      "From Birmingham at 03:17 AM to the moment the portal opens — every beat of the film, plotted.",
    url: storyboardAsset.url,
  },
  {
    id: "soundtrack",
    kicker: "II · SOUNDTRACK & AUDIO DESIGN",
    title: "The score, layer by layer.",
    caption:
      "Cinematic score, sub, sound design, and the six AIDES themes — all converging at 01:30 and 02:56.",
    url: soundtrackAsset.url,
  },
];

function ArchivePage() {
  const [open, setOpen] = useState<Panel | null>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(null);
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#05070d] text-[#f5e9c8]">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-60"
        style={{
          background:
            "radial-gradient(ellipse at 20% 10%, #d4af5a22 0%, transparent 50%), radial-gradient(ellipse at 80% 90%, #a06bff22 0%, transparent 55%), radial-gradient(ellipse at 50% 50%, #4bb8ff11 0%, transparent 70%)",
        }}
      />

      <header className="relative z-10 flex items-center justify-between px-6 pt-8 sm:px-12">
        <Link
          to="/"
          className="font-mono text-[10px] uppercase tracking-[0.3em] text-[#d4af5a]/80 transition hover:text-[#f5d97a]"
        >
          ← Back to the portal
        </Link>
        <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-[#f5e9c8]/40">
          TA Gurulabs · The Archive
        </span>
      </header>

      <section className="relative z-10 mx-auto max-w-5xl px-6 pt-20 pb-14 text-center sm:px-12">
        <p className="font-mono text-[11px] uppercase tracking-[0.4em] text-[#d4af5a]">
          Chapter One · Behind the Portal
        </p>
        <h1 className="mt-6 font-serif text-4xl leading-[1.05] tracking-tight text-[#f5d97a] sm:text-6xl md:text-7xl">
          The blueprint of a
          <br />
          <span className="italic text-[#f5e9c8]">cinematic reality.</span>
        </h1>
        <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-[#f5e9c8]/70 sm:text-lg">
          Every frame drawn. Every note plotted. Two documents that took the vision from
          03:17 AM in Birmingham to the moment the portal opens.
        </p>
      </section>

      <div className="relative z-10 mx-auto grid max-w-7xl gap-8 px-6 pb-24 sm:px-12 md:grid-cols-1">
        {PANELS.map((panel, idx) => (
          <button
            key={panel.id}
            onClick={() => setOpen(panel)}
            className="group relative overflow-hidden rounded-lg border border-[#d4af5a]/20 bg-black/40 text-left transition hover:border-[#d4af5a]/60"
          >
            <div className="relative aspect-[3/2] w-full overflow-hidden">
              <img
                src={panel.url}
                alt={panel.title}
                loading={idx === 0 ? "eager" : "lazy"}
                className="h-full w-full object-cover object-center transition duration-700 group-hover:scale-[1.02]"
              />
              <div
                aria-hidden
                className="pointer-events-none absolute inset-0"
                style={{
                  background:
                    "linear-gradient(180deg, transparent 40%, rgba(5,7,13,0.85) 100%)",
                }}
              />
            </div>
            <div className="relative flex items-end justify-between gap-6 p-6 sm:p-8">
              <div>
                <p className="font-mono text-[10px] uppercase tracking-[0.35em] text-[#d4af5a]">
                  {panel.kicker}
                </p>
                <h2 className="mt-3 font-serif text-2xl leading-tight text-[#f5d97a] sm:text-3xl">
                  {panel.title}
                </h2>
                <p className="mt-2 max-w-xl text-sm leading-relaxed text-[#f5e9c8]/70">
                  {panel.caption}
                </p>
              </div>
              <span className="hidden shrink-0 rounded-full border border-[#d4af5a]/40 px-4 py-2 font-mono text-[10px] uppercase tracking-[0.3em] text-[#d4af5a] transition group-hover:border-[#f5d97a] group-hover:text-[#f5d97a] sm:inline-block">
                Enlarge ↗
              </span>
            </div>
          </button>
        ))}
      </div>

      <footer className="relative z-10 border-t border-[#d4af5a]/10 px-6 py-8 text-center sm:px-12">
        <p className="font-serif text-sm italic text-[#f5e9c8]/50">
          "This isn't the end of the story… it's the beginning of yours."
        </p>
      </footer>

      {open ? (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex flex-col bg-black/95 backdrop-blur-sm"
          onClick={() => setOpen(null)}
        >
          <div className="flex items-center justify-between px-6 py-4 text-[#f5e9c8]">
            <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-[#d4af5a]">
              {open.kicker}
            </p>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setOpen(null);
              }}
              className="font-mono text-[10px] uppercase tracking-[0.3em] text-[#f5e9c8]/70 hover:text-[#f5d97a]"
            >
              Close ✕
            </button>
          </div>
          <PanZoomImage src={open.url} alt={open.title} />
          <p className="px-6 pb-4 text-center font-mono text-[10px] uppercase tracking-[0.3em] text-[#f5e9c8]/40">
            Scroll or pinch to zoom · drag to pan · Esc to close
          </p>
        </div>
      ) : null}
    </div>
  );
}

function PanZoomImage({ src, alt }: { src: string; alt: string }) {
  const [scale, setScale] = useState(1);
  const [tx, setTx] = useState(0);
  const [ty, setTy] = useState(0);
  const dragging = useRef<{ x: number; y: number } | null>(null);

  const clamp = (v: number, min: number, max: number) =>
    Math.max(min, Math.min(max, v));

  return (
    <div
      className="relative flex-1 select-none overflow-hidden"
      onClick={(e) => e.stopPropagation()}
      onWheel={(e) => {
        e.preventDefault();
        const next = clamp(scale + (e.deltaY < 0 ? 0.2 : -0.2), 1, 5);
        setScale(next);
        if (next === 1) {
          setTx(0);
          setTy(0);
        }
      }}
      onMouseDown={(e) => {
        dragging.current = { x: e.clientX - tx, y: e.clientY - ty };
      }}
      onMouseMove={(e) => {
        if (!dragging.current) return;
        setTx(e.clientX - dragging.current.x);
        setTy(e.clientY - dragging.current.y);
      }}
      onMouseUp={() => (dragging.current = null)}
      onMouseLeave={() => (dragging.current = null)}
      onDoubleClick={() => {
        setScale((s) => (s > 1 ? 1 : 2));
        setTx(0);
        setTy(0);
      }}
      style={{ cursor: scale > 1 ? "grab" : "zoom-in" }}
    >
      <img
        src={src}
        alt={alt}
        draggable={false}
        className="absolute left-1/2 top-1/2 max-h-[90vh] max-w-[95vw] -translate-x-1/2 -translate-y-1/2 transition-transform duration-100"
        style={{
          transform: `translate(calc(-50% + ${tx}px), calc(-50% + ${ty}px)) scale(${scale})`,
          transformOrigin: "center center",
        }}
      />
    </div>
  );
}