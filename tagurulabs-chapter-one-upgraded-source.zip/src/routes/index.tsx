import { createFileRoute } from "@tanstack/react-router";
import { Animatic } from "@/components/animatic/Animatic";
import ogImage from "@/assets/og-chapter-one.jpg";
import { getRequestOrigin } from "@/lib/origin.functions";

export const Route = createFileRoute("/")({
  loader: async () => ({ origin: await getRequestOrigin() }),
  head: ({ loaderData }) => {
    const origin = loaderData?.origin ?? "";
    const absoluteOg = origin ? `${origin}${ogImage}` : ogImage;
    return {
      meta: [
        { title: "TA GuruLabs — Chapter One: Enter the Portal" },
        {
          name: "description",
          content:
            "A cinematic animatic. A luminous portal, an ancient chamber, and a signal returning. Chapter One is open — request access.",
        },
        { property: "og:title", content: "TA GuruLabs — Chapter One: Enter the Portal" },
        {
          property: "og:description",
          content: "A cinematic animatic. Built by AIDES. Led by vision. Chapter One is open.",
        },
        { property: "og:type", content: "website" },
        { property: "og:url", content: origin ? `${origin}/` : "/" },
        { property: "og:image", content: absoluteOg },
        { property: "og:image:width", content: "1200" },
        { property: "og:image:height", content: "630" },
        { property: "og:image:alt", content: "A luminous golden portal in an ancient stone chamber." },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:title", content: "TA GuruLabs — Chapter One: Enter the Portal" },
        {
          name: "twitter:description",
          content: "A cinematic animatic. Built by AIDES. Led by vision.",
        },
        { name: "twitter:image", content: absoluteOg },
      ],
      links: [{ rel: "canonical", href: origin ? `${origin}/` : "/" }],
    };
  },
  component: Index,
});

function Index() {
  return <Animatic />;
}
