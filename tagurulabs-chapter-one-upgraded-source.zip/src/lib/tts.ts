// Client-side helper: POST text to /api/tts and stream PCM audio chunks into
// a Web Audio graph so playback begins as soon as the first bytes arrive.

export type TtsHandle = {
  stop: () => void;
  done: Promise<void>;
};

export function speakProphecy(text: string, opts: { voice?: string } = {}): TtsHandle {
  const controller = new AbortController();
  let stopped = false;
  let ctx: AudioContext | null = null;
  const sources: AudioBufferSourceNode[] = [];
  let playhead = 0;
  let pending = new Uint8Array(0);

  const stop = () => {
    if (stopped) return;
    stopped = true;
    controller.abort();
    for (const s of sources) {
      try { s.stop(); } catch { /* noop */ }
    }
    if (ctx && ctx.state !== "closed") {
      ctx.close().catch(() => {});
    }
  };

  const done = (async () => {
    try {
      const AC =
        (typeof window !== "undefined" &&
          ((window as unknown as { AudioContext?: typeof AudioContext }).AudioContext ??
            (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext)) ||
        null;
      if (!AC) return;
      ctx = new AC({ sampleRate: 24000 });
      if (ctx.state === "suspended") await ctx.resume().catch(() => {});

      const res = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, voice: opts.voice ?? "sage" }),
        signal: controller.signal,
      });
      if (!res.ok || !res.body) throw new Error(`TTS ${res.status}`);

      const reader = res.body.pipeThrough(new TextDecoderStream()).getReader();
      let buffer = "";

      const playBytes = (incoming: Uint8Array) => {
        if (stopped || !ctx) return;
        const merged = new Uint8Array(pending.length + incoming.length);
        merged.set(pending);
        merged.set(incoming, pending.length);
        const usable = merged.length - (merged.length % 2);
        pending = merged.slice(usable);
        if (usable === 0) return;
        const samples = new Int16Array(merged.buffer, 0, usable / 2);
        const floats = new Float32Array(samples.length);
        for (let i = 0; i < samples.length; i++) floats[i] = samples[i] / 32768;
        const buf = ctx.createBuffer(1, floats.length, 24000);
        buf.copyToChannel(floats, 0);
        const src = ctx.createBufferSource();
        src.buffer = buf;
        // Soft low-pass shimmer to feel more oracle-like.
        const filter = ctx.createBiquadFilter();
        filter.type = "lowpass";
        filter.frequency.value = 4200;
        const gain = ctx.createGain();
        gain.gain.value = 1.0;
        src.connect(filter).connect(gain).connect(ctx.destination);
        const now = ctx.currentTime;
        if (playhead === 0) playhead = now + 0.08;
        else playhead = Math.max(playhead, now);
        src.start(playhead);
        playhead += buf.duration;
        sources.push(src);
      };

      const handleEvent = (raw: string) => {
        // Each SSE event may span multiple `data:` lines.
        const dataLines = raw
          .split("\n")
          .filter((l) => l.startsWith("data:"))
          .map((l) => l.slice(5).trim());
        if (dataLines.length === 0) return;
        const payload = dataLines.join("");
        if (payload === "[DONE]") return;
        let parsed: { type?: string; audio?: string };
        try { parsed = JSON.parse(payload); } catch { return; }
        if (parsed.type === "speech.audio.delta" && typeof parsed.audio === "string") {
          const bin = atob(parsed.audio);
          const bytes = new Uint8Array(bin.length);
          for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
          playBytes(bytes);
        }
      };

      while (!stopped) {
        const { value, done: rDone } = await reader.read();
        if (rDone) break;
        buffer += value;
        let idx: number;
        while ((idx = buffer.indexOf("\n\n")) !== -1) {
          const raw = buffer.slice(0, idx);
          buffer = buffer.slice(idx + 2);
          handleEvent(raw);
        }
      }
      if (buffer.trim()) handleEvent(buffer);

      // Wait for scheduled audio to finish.
      if (ctx && playhead > ctx.currentTime && !stopped) {
        const remaining = (playhead - ctx.currentTime) * 1000;
        await new Promise((r) => setTimeout(r, Math.min(remaining + 200, 60_000)));
      }
    } catch (err) {
      if (!stopped) console.debug("speakProphecy failed", err);
    } finally {
      if (ctx && ctx.state !== "closed") ctx.close().catch(() => {});
    }
  })();

  return { stop, done };
}