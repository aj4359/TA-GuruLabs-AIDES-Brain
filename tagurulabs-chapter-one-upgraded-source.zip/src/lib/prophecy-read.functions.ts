import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import type { Database } from "@/integrations/supabase/types";

const IdSchema = z.object({ id: z.string().uuid() });

export const getProphecyById = createServerFn({ method: "GET" })
  .inputValidator((input: unknown) => IdSchema.parse(input))
  .handler(async ({ data }) => {
    const supabase = createClient<Database>(
      process.env.SUPABASE_URL!,
      process.env.SUPABASE_PUBLISHABLE_KEY!,
      { auth: { storage: undefined, persistSession: false, autoRefreshToken: false } },
    );
    const { data: row, error } = await supabase
      .from("prophecies")
      .select("id, prophecy, handle, created_at")
      .eq("id", data.id)
      .maybeSingle();
    if (error) {
      console.error("prophecy read failed", error);
      return null;
    }
    return row;
  });