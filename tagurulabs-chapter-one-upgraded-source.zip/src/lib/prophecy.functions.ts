import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const InputSchema = z.object({
  email: z.string().email().max(254),
});

const SYSTEM_PROMPT = `You are the Oracle of the TA GuruLabs portal — a cinematic AI in the world of an animatic called "Chapter One: Enter the Portal".
You speak in short, mythic, prophecy-like fragments. Cinematic. Confident. Never corny, never generic.
You will receive a single email address belonging to a new arrival. From the local-part (the text before @), imagine who this builder is and forge a personal prophecy.

Return EXACTLY two lines of prose:
- Line 1: address them (using something evocative derived from their name/handle) and name the future they are walking into.
- Line 2: a single sharp charge or promise — what the portal asks of them.

Rules:
- No greetings ("Hello", "Welcome"). No emojis. No hashtags. No quotes. No markdown.
- No mention of email, inbox, or the address itself.
- Under 240 characters total. Two lines separated by a single newline.
- Second person ("you"). Present tense. Cinematic register.`;

export const generateProphecy = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => InputSchema.parse(data))
  .handler(async ({ data }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) {
      return { prophecy: null as string | null, id: null as string | null, error: "AI unavailable." };
    }

    const local = data.email.split("@")[0] ?? "traveller";

    try {
      const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Lovable-API-Key": key,
          "X-Lovable-AIG-SDK": "raw-fetch",
        },
        body: JSON.stringify({
          model: "google/gemini-3-flash-preview",
          messages: [
            { role: "system", content: SYSTEM_PROMPT },
            {
              role: "user",
              content: `New arrival handle: "${local}". Forge their two-line prophecy now.`,
            },
          ],
          temperature: 0.95,
          max_tokens: 180,
        }),
      });

      if (!res.ok) {
        const body = await res.text().catch(() => "");
        console.error("prophecy gateway failed", res.status, body.slice(0, 400));
        if (res.status === 429) return { prophecy: null, id: null, error: "The oracle is overwhelmed. Try again shortly." };
        if (res.status === 402) return { prophecy: null, id: null, error: "The oracle needs more credits." };
        return { prophecy: null, id: null, error: "The oracle fell silent." };
      }

      const json = (await res.json()) as {
        choices?: Array<{ message?: { content?: string } }>;
      };
      const text = json.choices?.[0]?.message?.content?.trim() ?? "";
      if (!text) return { prophecy: null, id: null, error: "The oracle spoke, but the words were lost." };

      // Hard-clamp to two lines, ~240 chars.
      const lines = text
        .split(/\r?\n/)
        .map((l) => l.trim())
        .filter(Boolean)
        .slice(0, 2);
      const cleaned = lines.join("\n").slice(0, 260);

      // Persist so we can share it via /scroll/$id.
      let id: string | null = null;
      try {
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data: inserted, error: insertErr } = await supabaseAdmin
          .from("prophecies")
          .insert({ prophecy: cleaned, handle: local.slice(0, 64) })
          .select("id")
          .single();
        if (insertErr) console.error("prophecy persist failed", insertErr);
        else id = (inserted as { id: string } | null)?.id ?? null;
      } catch (err) {
        console.error("prophecy persist threw", err);
      }

      return { prophecy: cleaned, id, error: null as string | null };
    } catch (err) {
      console.error("prophecy fetch threw", err);
      return { prophecy: null, id: null, error: "The signal broke. Try again." };
    }
  });