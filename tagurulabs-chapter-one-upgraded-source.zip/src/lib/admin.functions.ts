import { createServerFn } from "@tanstack/react-start";
import { useSession } from "@tanstack/react-start/server";
import { redirect } from "@tanstack/react-router";
import { createHash, timingSafeEqual } from "node:crypto";

type AdminSession = { unlocked?: boolean };

function sessionConfig() {
  return {
    password: process.env.ADMIN_SESSION_SECRET!,
    name: "admin-gate",
    maxAge: 60 * 60 * 24 * 7,
    cookie: {
      httpOnly: true,
      secure: true,
      sameSite: "lax" as const,
      path: "/",
    },
  };
}

function passwordMatches(input: string, expected: string): boolean {
  const a = createHash("sha256").update(input, "utf8").digest();
  const b = createHash("sha256").update(expected, "utf8").digest();
  return timingSafeEqual(a, b);
}

async function requireUnlocked() {
  const session = await useSession<AdminSession>(sessionConfig());
  if (!session.data.unlocked) throw redirect({ to: "/admin/unlock" });
  return session;
}

export const unlockAdmin = createServerFn({ method: "POST" })
  .inputValidator((data: { password: string }) => data)
  .handler(async ({ data }) => {
    const expected = process.env.ADMIN_PASSWORD;
    if (!expected) throw new Error("ADMIN_PASSWORD is not set");
    if (!passwordMatches(data.password, expected)) {
      return { ok: false as const };
    }
    const session = await useSession<AdminSession>(sessionConfig());
    await session.update({ unlocked: true });
    return { ok: true as const };
  });

export const lockAdmin = createServerFn({ method: "POST" }).handler(async () => {
  const session = await useSession<AdminSession>(sessionConfig());
  await session.clear();
  return { ok: true as const };
});

export type FunnelRow = { event_type: string; count: number };
export type SceneRow = { scene_id: number; views: number };
export type AccessRequest = {
  id: string;
  email: string;
  source: string | null;
  created_at: string;
};

export type DashboardData = {
  totalSessions: number;
  funnel: FunnelRow[];
  scenes: SceneRow[];
  accessRequests: AccessRequest[];
  accessCount: number;
};

export const getAdminDashboard = createServerFn({ method: "GET" }).handler(
  async (): Promise<DashboardData> => {
    await requireUnlocked();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const [events, requests] = await Promise.all([
      supabaseAdmin
        .from("viewer_events")
        .select("session_id,event_type,scene_id")
        .limit(10000),
      supabaseAdmin
        .from("access_requests")
        .select("id,email,source,created_at")
        .order("created_at", { ascending: false })
        .limit(200),
    ]);

    const rows = events.data ?? [];
    const sessions = new Set<string>();
    const funnelMap = new Map<string, number>();
    const sceneMap = new Map<number, number>();
    for (const r of rows) {
      sessions.add(r.session_id);
      funnelMap.set(r.event_type, (funnelMap.get(r.event_type) ?? 0) + 1);
      if (r.event_type === "scene_view" && r.scene_id != null) {
        sceneMap.set(r.scene_id, (sceneMap.get(r.scene_id) ?? 0) + 1);
      }
    }

    const order = ["scene_view", "play", "pause", "complete", "replay", "share", "request_access"];
    const funnel: FunnelRow[] = order
      .filter((k) => funnelMap.has(k))
      .map((k) => ({ event_type: k, count: funnelMap.get(k)! }));

    const scenes: SceneRow[] = Array.from(sceneMap.entries())
      .sort((a, b) => a[0] - b[0])
      .map(([scene_id, views]) => ({ scene_id, views }));

    return {
      totalSessions: sessions.size,
      funnel,
      scenes,
      accessRequests: (requests.data ?? []) as AccessRequest[],
      accessCount: requests.data?.length ?? 0,
    };
  },
);