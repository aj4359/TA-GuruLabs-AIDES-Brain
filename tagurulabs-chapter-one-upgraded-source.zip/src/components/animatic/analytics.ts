import { supabase } from "@/integrations/supabase/client";

const SESSION_KEY = "ta_viewer_session_id";

function randomId(): string {
  try {
    if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
      return crypto.randomUUID().replace(/-/g, "");
    }
  } catch { /* noop */ }
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

export function getSessionId(): string {
  if (typeof window === "undefined") return "ssr_placeholder";
  try {
    const existing = sessionStorage.getItem(SESSION_KEY);
    if (existing && existing.length >= 8) return existing;
    const fresh = randomId().slice(0, 32);
    sessionStorage.setItem(SESSION_KEY, fresh);
    return fresh;
  } catch {
    return randomId().slice(0, 32);
  }
}

export type ViewerEventType =
  | "scene_view"
  | "play"
  | "pause"
  | "complete"
  | "replay"
  | "share"
  | "request_access";

export async function logViewerEvent(
  event_type: ViewerEventType,
  opts: { scene_id?: number | null; time_s?: number | null } = {},
): Promise<void> {
  if (typeof window === "undefined") return;
  const session_id = getSessionId();
  if (session_id === "ssr_placeholder") return;
  try {
    await supabase.from("viewer_events").insert({
      session_id,
      event_type,
      scene_id: opts.scene_id ?? null,
      time_s: opts.time_s ?? null,
      user_agent:
        typeof navigator !== "undefined" ? navigator.userAgent.slice(0, 500) : null,
    });
  } catch (err) {
    // Never let analytics break the UX.
    if (typeof console !== "undefined") console.debug("viewer_events insert failed", err);
  }
}