import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { SCENES, AIDES, TOTAL_DURATION, type Scene } from "./scenes";
import { AudioCues } from "./audio";
import { supabase } from "@/integrations/supabase/client";
import { logViewerEvent } from "./analytics";
import { generateProphecy } from "@/lib/prophecy.functions";
import { speakProphecy, type TtsHandle } from "@/lib/tts";

const fmt = (t: number) => {
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
};

function useAnimatic() {
  const [time, setTime] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [soundOn, setSoundOn] = useState(false);
  const raf = useRef<number | null>(null);
  const last = useRef<number>(0);
  const audio = useRef(new AudioCues());
  const narration = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const track = new Audio("/media/enter-the-portal.m4a");
    track.preload = "auto";
    track.volume = 1;
    narration.current = track;
    return () => {
      track.pause();
      narration.current = null;
    };
  }, []);

  useEffect(() => {
    audio.current.setEnabled(soundOn);
    if (narration.current) narration.current.muted = !soundOn;
  }, [soundOn]);

  useEffect(() => {
    if (!playing) {
      if (raf.current) cancelAnimationFrame(raf.current);
      return;
    }
    last.current = performance.now();
    const tick = (now: number) => {
      const dt = (now - last.current) / 1000;
      last.current = now;
      setTime((t) => {
        const next = t + dt;
        if (next >= TOTAL_DURATION) {
          setPlaying(false);
          return TOTAL_DURATION;
        }
        return next;
      });
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => {
      if (raf.current) cancelAnimationFrame(raf.current);
    };
  }, [playing]);

  // Keep Anthony's narration locked to the director timeline.
  useEffect(() => {
    const track = narration.current;
    if (!track) return;
    if (Math.abs(track.currentTime - time) > 0.45) track.currentTime = time;
    if (playing && soundOn) track.play().catch(() => undefined);
    else track.pause();
  }, [playing, soundOn]);

  useEffect(() => {
    const track = narration.current;
    if (!track || playing) return;
    if (Math.abs(track.currentTime - time) > 0.15) track.currentTime = time;
  }, [time, playing]);

  // audio triggers
  useEffect(() => {
    const a = audio.current;
    if (!soundOn) return;
    const trigs: Array<[number, string, () => void]> = [
      [2, "hb1", () => a.heartbeat(0.6)],
      [4, "hb2", () => a.heartbeat(0.85)],
      [5, "hb3", () => a.heartbeat(1)],
      [36, "riser1", () => a.riser(4)],
      [40, "portal-awaken", () => a.portalHit()],
      [66, "riser2", () => a.riser(4)],
      [70, "portal-open", () => a.portalHit()],
      [157, "riser3", () => a.riser(4)],
      [176, "final", () => a.finalStinger()],
    ];
    trigs.forEach(([t, key, fn]) => {
      if (time >= t) a.triggerOnce(key, fn);
    });
  }, [time, soundOn]);

  // Continuous score bed — starts on play, follows the scene, stops on pause/end.
  useEffect(() => {
    const a = audio.current;
    if (!soundOn) return;
    if (playing && time > 0) a.startBed(55);
    else a.stopBed();
  }, [soundOn, playing, time]);

  // Adaptive bed + arp based on current scene
  useEffect(() => {
    const a = audio.current;
    if (!soundOn || !playing) return;
    const { scene } = currentScene(time);
    // Emotion → tonic (Hz, roughly). Curiosity/loneliness low, hope mid, power/purpose bright.
    const tonics: Record<string, number> = {
      Curiosity: 49, Loneliness: 52, Hope: 55, Discovery: 65,
      Wonder: 69, Power: 73, Belonging: 82, Silence: 41, Purpose: 87,
    };
    const tonic = tonics[scene.emotion] ?? 55;
    a.setBed({
      tonicHz: tonic,
      intensity: scene.silence ? 0.0 : 0.15 + scene.energy * 0.85,
      brightness: scene.silence ? 0.05 : 0.15 + scene.energy * 0.85,
    });
    if (scene.showAides) a.startArp(tonic * 4, 240);
    else a.stopArp();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [soundOn, playing, currentScene(time).scene.id]);

  const reset = () => {
    setTime(0);
    setPlaying(false);
    audio.current.reset();
    if (narration.current) narration.current.currentTime = 0;
  };

  return { time, setTime, playing, setPlaying, soundOn, setSoundOn, reset };
}

function currentScene(t: number): { scene: Scene; localT: number; progress: number } {
  const scene = SCENES.find((s) => t >= s.start && t < s.end) ?? SCENES[SCENES.length - 1];
  const localT = t - scene.start;
  const progress = Math.min(1, Math.max(0, localT / (scene.end - scene.start)));
  return { scene, localT, progress };
}

const DYNAMICS = ["ppp", "pp", "mp", "mf", "f", "ff", "fff"];

export function Animatic() {
  const { time, setTime, playing, setPlaying, soundOn, setSoundOn, reset } = useAnimatic();
  const { scene, progress } = useMemo(() => currentScene(time), [time]);

  const dynIdx = Math.min(DYNAMICS.length - 1, Math.floor(scene.energy * DYNAMICS.length));

  // Analytics: log scene changes.
  useEffect(() => {
    logViewerEvent("scene_view", { scene_id: scene.id, time_s: Math.round(time) });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scene.id]);

  // Analytics: log play / pause.
  const wasPlaying = useRef(false);
  useEffect(() => {
    if (playing && !wasPlaying.current) {
      logViewerEvent("play", { scene_id: scene.id, time_s: Math.round(time) });
    } else if (!playing && wasPlaying.current) {
      logViewerEvent("pause", { scene_id: scene.id, time_s: Math.round(time) });
    }
    wasPlaying.current = playing;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playing]);

  // Analytics: log completion (once per session run-through).
  const completedRef = useRef(false);
  useEffect(() => {
    if (time >= TOTAL_DURATION - 0.05 && !completedRef.current) {
      completedRef.current = true;
      logViewerEvent("complete", { scene_id: scene.id, time_s: Math.round(time) });
    }
    if (time < 1) completedRef.current = false;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [time]);

  // Parallax: track pointer position relative to the stage
  const stageRef = useRef<HTMLDivElement | null>(null);
  const [parallax, setParallax] = useState({ x: 0, y: 0 });
  const onStageMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const el = stageRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const x = ((e.clientX - r.left) / r.width - 0.5) * 2;
    const y = ((e.clientY - r.top) / r.height - 0.5) * 2;
    setParallax({ x, y });
  };
  const onStageLeave = () => setParallax({ x: 0, y: 0 });

  return (
    <div
      className="relative min-h-screen w-full overflow-hidden font-sans"
      style={{ color: "#e6e2d3", background: "#04050a" }}
    >
      {/* Global aurora backdrop */}
      <div className="pointer-events-none fixed inset-0 -z-10">
        <div
          className="absolute -inset-[20%]"
          style={{
            background:
              "radial-gradient(ellipse 60% 50% at 20% 30%, rgba(212,175,90,0.18), transparent 60%), radial-gradient(ellipse 55% 45% at 80% 70%, rgba(75,184,255,0.14), transparent 60%), radial-gradient(ellipse 50% 40% at 50% 100%, rgba(160,107,255,0.14), transparent 60%)",
            animation: "ta-aurora 24s ease-in-out infinite",
            filter: "blur(40px)",
          }}
        />
        <div
          className="absolute inset-0 opacity-[0.08]"
          style={{
            backgroundImage:
              "linear-gradient(rgba(212,175,90,0.35) 1px, transparent 1px), linear-gradient(90deg, rgba(212,175,90,0.35) 1px, transparent 1px)",
            backgroundSize: "80px 80px",
            maskImage:
              "radial-gradient(ellipse at center, black 40%, transparent 80%)",
          }}
        />
      </div>

      {/* Top HUD */}
      <TopHud time={time} scene={scene} dynIdx={dynIdx} />

      {/* Stage */}
      <div className="mx-auto w-full max-w-[1600px] px-3 pt-4 md:px-6 md:pt-6">
        <div
          ref={stageRef}
          onMouseMove={onStageMove}
          onMouseLeave={onStageLeave}
          className="relative aspect-video w-full overflow-hidden rounded-lg ring-1 ring-white/10"
          style={{
            background: scene.bg,
            boxShadow:
              "0 40px 120px -30px rgba(212,175,90,0.25), 0 0 0 1px rgba(212,175,90,0.15) inset",
          }}
        >
          {/* Deep parallax back layer */}
          <div
            className="pointer-events-none absolute inset-[-8%] transition-transform duration-500 ease-out"
            style={{
              transform: `translate3d(${parallax.x * -18}px, ${parallax.y * -12}px, 0) scale(1.05)`,
              background: `radial-gradient(ellipse 60% 50% at 30% 40%, ${scene.accent}18, transparent 60%), radial-gradient(ellipse 55% 45% at 70% 65%, ${scene.accent}0f, transparent 60%)`,
              filter: "blur(30px)",
            }}
          />

          {/* Foreground scene layer with mid-parallax */}
          <div
            className="absolute inset-0 transition-transform duration-500 ease-out"
            style={{
              transform: `translate3d(${parallax.x * 10}px, ${parallax.y * 6}px, 0)`,
            }}
          >
            <SceneRenderer scene={scene} progress={progress} time={time} />
          </div>

          {/* Chromatic aberration flash on scene change */}
          <div
            key={`chroma-${scene.id}`}
            className="pointer-events-none absolute inset-0 mix-blend-screen"
            style={{
              background:
                "linear-gradient(90deg, rgba(255,60,60,0.18) 0%, transparent 40%, transparent 60%, rgba(60,180,255,0.18) 100%)",
              animation: "ta-chromatic 900ms ease-out 1 forwards",
              opacity: 0,
            }}
          />

          {/* Volumetric god-rays */}
          <div className="pointer-events-none absolute inset-0 overflow-hidden mix-blend-screen">
            <div
              className="absolute -inset-y-[20%] left-1/2 h-[140%] w-[60%] -translate-x-1/2"
              style={{
                background: `repeating-linear-gradient(105deg, ${scene.accent}22 0px, ${scene.accent}22 2px, transparent 3px, transparent 22px)`,
                filter: "blur(6px)",
                maskImage:
                  "radial-gradient(ellipse 60% 50% at 50% 0%, black 0%, transparent 70%)",
                WebkitMaskImage:
                  "radial-gradient(ellipse 60% 50% at 50% 0%, black 0%, transparent 70%)",
                animation: "ta-godray-sweep 14s ease-in-out infinite alternate",
                opacity: 0.5,
              }}
            />
          </div>

          {/* Vignette */}
          <div
            className="pointer-events-none absolute inset-0"
            style={{
              background:
                "radial-gradient(ellipse at center, transparent 45%, rgba(0,0,0,0.85) 100%)",
            }}
          />
          {/* Scan lines */}
          <div
            className="pointer-events-none absolute inset-0 mix-blend-overlay opacity-40"
            style={{
              backgroundImage:
                "repeating-linear-gradient(0deg, rgba(255,255,255,0.04) 0px, rgba(255,255,255,0.04) 1px, transparent 1px, transparent 3px)",
            }}
          />
          {/* Moving scan bar */}
          <div
            className="pointer-events-none absolute inset-x-0 h-24 opacity-30"
            style={{
              background:
                "linear-gradient(to bottom, transparent, rgba(212,175,90,0.18), transparent)",
              animation: "ta-scan-line 9s linear infinite",
            }}
          />

          {/* Film grain (SVG turbulence) */}
          <div
            className="pointer-events-none absolute -inset-[10%] opacity-[0.18] mix-blend-overlay"
            style={{
              backgroundImage:
                "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='240' height='240'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 0.55 0'/></filter><rect width='100%25' height='100%25' filter='url(%23n)'/></svg>\")",
              backgroundSize: "240px 240px",
              animation: "ta-grain 900ms steps(6) infinite",
            }}
          />

          {/* Cinematic 2.39:1 letterbox */}
          <div
            className="pointer-events-none absolute inset-x-0 top-0 h-[12.5%] bg-black"
            style={{ boxShadow: "0 8px 24px -8px rgba(0,0,0,0.9)" }}
          />
          <div
            className="pointer-events-none absolute inset-x-0 bottom-0 h-[12.5%] bg-black"
            style={{ boxShadow: "0 -8px 24px -8px rgba(0,0,0,0.9)" }}
          />

          {/* Corner marks */}
          <CornerMarks />

          {/* Timecode overlay */}
          <div className="pointer-events-none absolute bottom-[13.5%] right-4 md:right-6 flex items-center gap-2 text-[10px] uppercase tracking-[0.4em] text-white/50">
            <span className="inline-block h-1.5 w-1.5 rounded-full bg-red-500" style={{ animation: "ta-pulse 1.4s ease-in-out infinite" }} />
            REC · {fmt(time)}
          </div>

          {/* End card overlay — appears when animatic completes */}
          {time >= TOTAL_DURATION - 0.05 && !playing && (
            <EndCard onReplay={() => { reset(); setPlaying(true); }} />
          )}
        </div>
      </div>

      {/* Transport */}
      <Transport
        time={time}
        setTime={setTime}
        playing={playing}
        setPlaying={setPlaying}
        soundOn={soundOn}
        setSoundOn={setSoundOn}
        reset={reset}
      />

      {/* Scene strip */}
      <SceneStrip time={time} onSeek={setTime} />

      {/* Sound design panel */}
      <SoundPanel scene={scene} />

      {/* Storyboard sections */}
      <StoryboardHeader />
      <StoryboardGrid onSeek={setTime} />
      <AidesRoster />
      <ClosingQuote />
    </div>
  );
}

function CornerMarks() {
  const mark = "absolute h-4 w-4 border-aurum/60";
  return (
    <>
      <div className={`${mark} left-4 top-[13.5%] border-l border-t`} style={{ borderColor: "#d4af5a99" }} />
      <div className={`${mark} right-4 top-[13.5%] border-r border-t`} style={{ borderColor: "#d4af5a99" }} />
      <div className={`${mark} left-4 bottom-[13.5%] border-l border-b`} style={{ borderColor: "#d4af5a99" }} />
      <div className={`${mark} right-4 bottom-[13.5%] border-r border-b`} style={{ borderColor: "#d4af5a99" }} />
    </>
  );
}

function TopHud({ time, scene, dynIdx }: { time: number; scene: Scene; dynIdx: number }) {
  void dynIdx;
  return (
    <div className="sticky top-0 z-30 backdrop-blur-xl" style={{ background: "linear-gradient(180deg, rgba(4,5,10,0.9), rgba(4,5,10,0.55))" }}>
      <div className="h-px w-full" style={{ background: "linear-gradient(90deg, transparent, #d4af5a, transparent)", opacity: 0.6 }} />
      <div className="mx-auto flex w-full max-w-[1920px] flex-wrap items-end justify-between gap-3 border-b border-[#d4af5a]/20 px-4 pb-3 pt-3 font-mono text-[10px] uppercase tracking-[0.2em] md:px-8" style={{ color: "#d4af5a" }}>
        <div className="flex flex-wrap items-center gap-4 md:gap-8">
          <span className="flex items-center gap-2">
            <span className="inline-block h-2 w-2" style={{ background: "#d4af5a", boxShadow: "0 0 8px #d4af5a", animation: "ta-pulse 1.4s ease-in-out infinite" }} />
            REC: LIVE_FEED
          </span>
          <span style={{ color: "#4bb8ff" }}>CH_01 // ENTER_THE_PORTAL</span>
          <span className="hidden md:inline text-white/50">EMOTION: {scene.emotion.toUpperCase()}</span>
        </div>
        <div className="flex flex-wrap items-center gap-4 md:gap-8 md:text-right">
          <span className="text-white/50">COORD: 52.4862° N, 1.8904° W</span>
          <span style={{ color: "#a06bff" }}>SIG_STRENGTH: 98.4%</span>
          <span className="tabular-nums" style={{ color: "#f5d97a" }}>{fmt(time)} / {fmt(TOTAL_DURATION)}</span>
        </div>
      </div>
    </div>
  );
}

function sceneMedia(scene: Scene) {
  if (scene.portal || scene.logoReveal) return "/media/portal-world.png";
  if (scene.showAides) return "/media/game-interface.png";
  if (scene.id >= 5 && scene.id <= 8) return "/media/storyboard-sheet.png";
  return null;
}

function SceneRenderer({ scene, progress, time }: { scene: Scene; progress: number; time: number }) {
  return (
    <div
      key={scene.id}
      className="absolute inset-0"
      style={{ animation: "ta-cinematic-in 1100ms cubic-bezier(0.22, 1, 0.36, 1) both" }}
    >
      {sceneMedia(scene) && (
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <img
            src={sceneMedia(scene) ?? ""}
            alt=""
            className="h-full w-full object-cover"
            style={{
              opacity: scene.portal ? 0.46 : scene.showAides ? 0.34 : 0.22,
              filter: "contrast(1.28) saturate(0.9) brightness(0.72)",
              transform: `scale(${1.08 + progress * 0.08}) translate3d(0, ${-progress * 1.5}%, 0)`,
              transition: "transform 180ms linear",
            }}
          />
          <div
            className="absolute inset-0"
            style={{ background: "linear-gradient(90deg, rgba(3,4,8,.92), rgba(3,4,8,.18) 48%, rgba(3,4,8,.86))" }}
          />
        </div>
      )}
      {/* Particle drift */}
      <ParticleField accent={scene.accent} density={0.3 + scene.energy * 0.7} />

      {/* Portal */}
      {scene.portal && <PortalRing accent={scene.accent} intensity={scene.energy} />}

      {/* AIDES grid */}
      {scene.showAides && <AidesReveal progress={progress} />}

      {/* Chapter time badge */}
      <div className="absolute left-8 top-8 text-[10px] uppercase tracking-[0.3em] text-white/60">{scene.chapter}</div>

      {/* Logos */}
      {scene.logos && scene.logos.length > 0 && (
        <div className="absolute right-8 top-8 flex flex-col items-end gap-2">
          {scene.logos.map((l, i) => (
            <div
              key={l}
              className="rounded border border-white/20 bg-black/40 px-3 py-1 text-[11px] tracking-[0.2em] text-white/90 backdrop-blur-sm"
              style={{ animation: `ta-fade-in 500ms ease-out ${i * 150}ms both` }}
            >
              {l}
            </div>
          ))}
        </div>
      )}

      {/* Silence beat */}
      {scene.silence && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-[10px] uppercase tracking-[0.5em] text-white/20">— silence —</div>
        </div>
      )}

      {/* Final logo */}
      {scene.logoReveal && <FinalLogo />}

      {/* Headline + caption */}
      {!scene.silence && !scene.logoReveal && (
        <div className="absolute inset-0 flex flex-col items-center justify-center px-8 text-center">
          <h1
            className={`font-display text-3xl md:text-5xl lg:text-6xl tracking-[0.1em] ${scene.glitch ? "" : ""}`}
            style={{
              color: scene.accent,
              textShadow: `0 0 40px ${scene.accent}55, 0 0 80px ${scene.accent}22`,
              animation: scene.glitch ? "ta-glitch 1.2s steps(2) 1" : "ta-fade-in 900ms ease-out",
            }}
          >
            {scene.headline}
          </h1>
          <p className="mt-6 max-w-2xl text-sm md:text-base font-light tracking-wide text-white/75" style={{ animation: "ta-fade-in 1100ms ease-out 200ms both" }}>
            {scene.caption}
          </p>
          {scene.vo && (
            <div className="mt-8 flex items-center gap-3 text-[10px] uppercase tracking-[0.35em] text-white/50">
              <span className="inline-block h-1.5 w-1.5 rounded-full" style={{ backgroundColor: scene.accent, animation: "ta-pulse 1.4s ease-in-out infinite" }} />
              VO · Anthony · “{scene.vo}”
            </div>
          )}
        </div>
      )}

      {/* Final hit flash */}
      {scene.finalHit && time >= 176 && time < 176.3 && (
        <div className="absolute inset-0 bg-white" style={{ animation: "ta-flicker 300ms ease-out" }} />
      )}
    </div>
  );
}

function ParticleField({ accent, density }: { accent: string; density: number }) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const dots = useMemo(() => {
    const n = Math.floor(40 + density * 80);
    return Array.from({ length: n }, (_, i) => ({
      x: Math.random() * 100,
      y: Math.random() * 100,
      s: 1 + Math.random() * 2.5,
      d: 3 + Math.random() * 6,
      o: 0.15 + Math.random() * 0.5,
      k: i,
    }));
  }, [density]);
  if (!mounted) return <div className="absolute inset-0 overflow-hidden" />;
  return (
    <div className="absolute inset-0 overflow-hidden">
      {dots.map((p) => (
        <span
          key={p.k}
          className="absolute rounded-full"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: p.s,
            height: p.s,
            backgroundColor: accent,
            opacity: p.o,
            filter: "blur(0.4px)",
            animation: `ta-drift ${p.d}s ease-in-out infinite`,
          }}
        />
      ))}
    </div>
  );
}

function PortalRing({ accent, intensity }: { accent: string; intensity: number }) {
  return (
    <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
      <div
        className="relative"
        style={{
          width: `${40 + intensity * 30}%`,
          aspectRatio: "1 / 1",
        }}
      >
        {/* Conic sweep */}
        <div
          className="absolute inset-0 rounded-full"
          style={{
            background: `conic-gradient(from 0deg, transparent 0deg, ${accent}88 90deg, transparent 180deg, ${accent}55 270deg, transparent 360deg)`,
            animation: "ta-conic 12s linear infinite",
            filter: "blur(6px)",
            opacity: 0.55,
            maskImage: "radial-gradient(circle, transparent 40%, black 42%, black 60%, transparent 62%)",
            WebkitMaskImage: "radial-gradient(circle, transparent 40%, black 42%, black 60%, transparent 62%)",
          }}
        />
        {[0, 1, 2, 3].map((i) => (
          <div
            key={i}
            className="absolute inset-0 rounded-full"
            style={{
              border: `1px solid ${accent}`,
              opacity: 0.12 + i * 0.14,
              transform: `scale(${1 - i * 0.12})`,
              boxShadow: `0 0 ${40 + i * 30}px ${accent}66, inset 0 0 60px ${accent}44`,
              animation: `ta-portal-spin ${18 + i * 7}s linear infinite ${i % 2 ? "reverse" : ""}`,
            }}
          />
        ))}
        <div
          className="absolute inset-[18%] rounded-full"
          style={{
            background: `radial-gradient(circle, ${accent}77 0%, ${accent}22 40%, transparent 70%)`,
            animation: "ta-pulse 3s ease-in-out infinite",
            filter: "blur(2px)",
          }}
        />
        {/* Center core */}
        <div
          className="absolute left-1/2 top-1/2 h-2 w-2 -translate-x-1/2 -translate-y-1/2 rounded-full"
          style={{ background: "#fff", boxShadow: `0 0 20px #fff, 0 0 60px ${accent}` }}
        />
      </div>
    </div>
  );
}

function AidesReveal({ progress }: { progress: number }) {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center px-8">
      <div className="mb-8 font-display text-2xl md:text-4xl tracking-[0.2em]" style={{ color: "#d4af5a", textShadow: "0 0 40px #d4af5a55" }}>
        MEET THE AIDES
      </div>
      <div className="grid w-full max-w-5xl grid-cols-3 gap-4 md:grid-cols-6">
        {AIDES.map((a, i) => {
          const reveal = progress > i / (AIDES.length + 1);
          return (
            <div
              key={a.name}
              className="flex flex-col items-center gap-2 rounded border border-white/10 bg-black/30 p-3 backdrop-blur-sm transition-all duration-700"
              style={{
                opacity: reveal ? 1 : 0,
                transform: reveal ? "translateY(0)" : "translateY(12px)",
                boxShadow: reveal ? `0 0 40px ${a.color}33, inset 0 0 20px ${a.color}22` : "none",
                borderColor: reveal ? `${a.color}66` : "rgba(255,255,255,0.08)",
              }}
            >
              <div
                className="h-14 w-14 rounded-full"
                style={{
                  background: `radial-gradient(circle, ${a.color} 0%, ${a.color}00 70%)`,
                  boxShadow: `0 0 30px ${a.color}88`,
                  animation: reveal ? "ta-pulse 2.4s ease-in-out infinite" : "none",
                }}
              />
              <div className="font-display text-sm tracking-[0.2em]" style={{ color: a.color }}>{a.name}</div>
              <div className="text-[9px] uppercase tracking-[0.3em] text-white/60">{a.role}</div>
              <div className="text-[9px] text-white/40">{a.motif}</div>
            </div>
          );
        })}
      </div>
      <div className="mt-8 max-w-2xl text-center text-sm text-white/70">
        Not tools. Not bots. A digital workforce. Each with a purpose. Together, unstoppable.
      </div>
    </div>
  );
}

function FinalLogo() {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center">
      <div
        className="font-display leading-none"
        style={{
          fontSize: "clamp(64px, 12vw, 180px)",
          color: "#f5d97a",
          letterSpacing: "0.05em",
          textShadow: "0 0 60px #f5d97aaa, 0 0 120px #d4af5a66",
          animation: "ta-fade-in 900ms ease-out",
        }}
      >
        TA
      </div>
      <div className="mt-4 font-display text-lg tracking-[0.6em]" style={{ color: "#d4af5a", animation: "ta-fade-in 1200ms ease-out 300ms both" }}>
        GURULABS
      </div>
      <div className="mt-6 text-[10px] uppercase tracking-[0.4em] text-white/50" style={{ animation: "ta-fade-in 1400ms ease-out 600ms both" }}>
        Enter the Portal
      </div>
    </div>
  );
}

function Transport({
  time,
  setTime,
  playing,
  setPlaying,
  soundOn,
  setSoundOn,
  reset,
}: {
  time: number;
  setTime: (n: number) => void;
  playing: boolean;
  setPlaying: (b: boolean) => void;
  soundOn: boolean;
  setSoundOn: (b: boolean) => void;
  reset: () => void;
}) {
  const pct = (time / TOTAL_DURATION) * 100;
  return (
    <div className="mx-auto mt-6 grid w-full max-w-[1920px] grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-6 px-4 md:px-8">
      {/* Tactical play */}
      <button
        type="button"
        onClick={() => setPlaying(!playing)}
        className="group relative grid h-14 w-14 shrink-0 place-items-center rounded-full border transition-all duration-300 hover:bg-[#d4af5a] hover:text-[#05070d] active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#f5d97a]"
        style={{
          borderColor: "#d4af5a",
          color: "#d4af5a",
          boxShadow: playing ? "0 0 30px rgba(212,175,90,0.35), inset 0 0 20px rgba(212,175,90,0.15)" : "0 0 0 rgba(0,0,0,0)",
        }}
        aria-label={playing ? "Pause" : "Play"}
      >
        {playing ? (
          <span className="flex gap-[3px]"><span className="block h-4 w-[3px] bg-current" /><span className="block h-4 w-[3px] bg-current" /></span>
        ) : (
          <span
            className="ml-1 block"
            style={{ width: 0, height: 0, borderTop: "7px solid transparent", borderBottom: "7px solid transparent", borderLeft: "12px solid currentColor" }}
          />
        )}
        <span className="pointer-events-none absolute inset-0 rounded-full opacity-40" style={{ boxShadow: "0 0 40px #d4af5a55" }} />
      </button>

      {/* Progress rail */}
      <div className="relative min-w-0">
        <div className="relative h-[2px] w-full bg-white/10">
          <div
            className="absolute inset-y-0 left-0"
            style={{ width: `${pct}%`, background: "#d4af5a", boxShadow: "0 0 15px #d4af5a" }}
          />
          <div
            className="absolute top-[-4px] h-[10px] w-[3px]"
            style={{ left: `calc(${pct}% - 1.5px)`, background: "#f5d97a", boxShadow: "0 0 12px #f5d97a" }}
          />
        </div>
        <input
          type="range"
          min={0}
          max={TOTAL_DURATION}
          step={0.1}
          value={time}
          onChange={(e) => setTime(parseFloat(e.target.value))}
          className="absolute inset-0 h-6 w-full -translate-y-2 cursor-pointer appearance-none bg-transparent [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-transparent"
          aria-label="Scrub timeline"
        />
        <div className="mt-3 flex flex-wrap items-center justify-between gap-3 font-mono text-[10px] uppercase tracking-[0.25em] text-white/50">
          <span>TRANSPORT · {playing ? "PLAY" : "PAUSED"}</span>
          <span className="tabular-nums" style={{ color: "#f5d97a" }}>{fmt(time)} / {fmt(TOTAL_DURATION)}</span>
        </div>
      </div>

      {/* Secondary controls */}
      <div className="flex shrink-0 flex-col gap-2">
        <TacticalPill onClick={() => setSoundOn(!soundOn)} active={soundOn} accent="#4bb8ff">
          AUDIO + VO: {soundOn ? "LIVE" : "MUTED"}
        </TacticalPill>
        <TacticalPill onClick={reset} accent="#a06bff">
          MODE: DIRECTOR_CUT · ↻
        </TacticalPill>
      </div>
    </div>
  );
}

function TacticalPill({ children, onClick, active, accent }: { children: ReactNode; onClick: () => void; active?: boolean; accent: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="group inline-flex items-center gap-2 border px-3 py-1.5 font-mono text-[10px] uppercase tracking-[0.25em] transition-all duration-200 hover:bg-white/[0.04] active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#f5d97a]"
      style={{
        borderColor: active ? accent : "rgba(255,255,255,0.12)",
        color: active ? accent : "rgba(255,255,255,0.7)",
        boxShadow: active ? `0 0 20px ${accent}44, inset 0 0 12px ${accent}22` : "none",
      }}
    >
      <span
        className="inline-block h-1.5 w-1.5"
        style={{ background: active ? accent : "rgba(255,255,255,0.25)", boxShadow: active ? `0 0 6px ${accent}` : "none" }}
      />
      {children}
    </button>
  );
}

function TButton({
  children,
  onClick,
  primary,
  active,
}: {
  children: ReactNode;
  onClick: () => void;
  primary?: boolean;
  active?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="group relative inline-flex items-center gap-2 rounded-md px-4 py-2 text-[11px] uppercase tracking-[0.3em] transition-all duration-200 active:scale-[0.97] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#f5d97a] focus-visible:ring-offset-2 focus-visible:ring-offset-black"
      style={{
        border: `1px solid ${primary ? "#d4af5a" : "rgba(255,255,255,0.18)"}`,
        color: primary ? "#f5d97a" : "rgba(255,255,255,0.85)",
        background: active
          ? "linear-gradient(180deg, rgba(245,217,122,0.18), rgba(212,175,90,0.06))"
          : "linear-gradient(180deg, rgba(255,255,255,0.04), rgba(255,255,255,0.01))",
        boxShadow: active
          ? "0 0 24px rgba(245,217,122,0.35), inset 0 0 12px rgba(245,217,122,0.15)"
          : "0 1px 0 rgba(255,255,255,0.05) inset",
      }}
    >
      <span
        className="pointer-events-none absolute inset-0 rounded-md opacity-0 transition-opacity duration-200 group-hover:opacity-100"
        style={{
          background:
            "radial-gradient(120px 60px at var(--mx,50%) var(--my,50%), rgba(245,217,122,0.18), transparent 70%)",
        }}
      />
      {children}
    </button>
  );
}

function SceneStrip({ time, onSeek }: { time: number; onSeek: (t: number) => void }) {
  return (
    <div className="mx-auto mt-4 max-w-[1600px] px-3 md:px-6">
      <div className="overflow-x-auto rounded-lg border border-white/10 bg-white/[0.02] backdrop-blur-md">
      <div className="flex min-w-max">
        {SCENES.map((s) => {
          const active = time >= s.start && time < s.end;
          const width = ((s.end - s.start) / TOTAL_DURATION) * 1600;
          return (
            <button
              key={s.id}
              onClick={() => onSeek(s.start)}
              className="group relative border-r border-white/10 px-3 py-3 text-left transition-all duration-200 hover:bg-white/[0.04] active:scale-[0.99]"
              style={{
                width: Math.max(120, width),
                background: active
                  ? "linear-gradient(180deg, rgba(212,175,90,0.15), rgba(212,175,90,0.02))"
                  : "transparent",
                borderTop: active ? `2px solid ${s.accent}` : "2px solid transparent",
                boxShadow: active ? `inset 0 -2px 0 ${s.accent}55` : "none",
              }}
            >
              <div className="text-[9px] uppercase tracking-[0.25em] text-white/50">{s.chapter}</div>
              <div className="mt-1 font-display text-[11px] tracking-[0.15em]" style={{ color: s.accent }}>
                {s.headline || s.emotion.toUpperCase()}
              </div>
              <div className="mt-1 text-[9px] uppercase tracking-[0.2em] text-white/40">{s.emotion}</div>
            </button>
          );
        })}
      </div>
      </div>
    </div>
  );
}

function SoundPanel({ scene }: { scene: Scene }) {
  return (
    <div className="mx-auto mt-4 grid max-w-[1600px] gap-3 px-3 pb-8 md:grid-cols-4 md:gap-4 md:px-6">
      <PanelBlock label="Cinematic Score" value={scene.score} />
      <PanelBlock label="Sound Design / SFX" value={scene.sfx} />
      <PanelBlock label="Dynamics" value={scene.dynamics} />
      <PanelBlock label="Emotion" value={scene.emotion} />
    </div>
  );
}

function PanelBlock({ label, value }: { label: string; value: string }) {
  return (
    <div
      className="group relative overflow-hidden rounded-lg border border-white/10 bg-white/[0.02] p-4 backdrop-blur-sm transition-all duration-300 hover:border-aurum/40 hover:bg-white/[0.04]"
      style={{ boxShadow: "inset 0 1px 0 rgba(255,255,255,0.04)" }}
    >
      <div
        className="pointer-events-none absolute inset-x-0 -top-px h-px opacity-70"
        style={{ background: "linear-gradient(90deg, transparent, #d4af5a88, transparent)" }}
      />
      <div className="text-[9px] uppercase tracking-[0.35em]" style={{ color: "#d4af5a" }}>{label}</div>
      <div className="mt-2 text-sm text-white/90">{value}</div>
    </div>
  );
}

function GoldText({ children, className = "", size = "text-4xl md:text-6xl" }: { children: ReactNode; className?: string; size?: string }) {
  return (
    <span
      className={`font-display ${size} ${className}`}
      style={{
        background: "linear-gradient(180deg, #f5d97a 0%, #d4af5a 55%, #7c5d20 100%)",
        WebkitBackgroundClip: "text",
        backgroundClip: "text",
        color: "transparent",
        textShadow: "0 0 40px rgba(212,175,90,0.35)",
        letterSpacing: "0.08em",
      }}
    >
      {children}
    </span>
  );
}

function StoryboardHeader() {
  return (
    <section className="mx-auto w-full max-w-[1920px] px-4 pb-8 pt-24 md:px-8 md:pt-32">
      <div className="grid grid-cols-1 gap-6 md:grid-cols-[minmax(0,1fr)_auto] md:items-end">
        <div>
          <div className="font-mono text-[10px] uppercase tracking-[0.4em]" style={{ color: "#4bb8ff" }}>SEQ_00_OVERTURE</div>
          <h1 className="mt-4 font-display text-5xl font-light uppercase leading-[0.95] tracking-[0.02em] text-white md:text-7xl lg:text-8xl">
            Enter the <span style={{ color: "#d4af5a" }}>Portal.</span>
          </h1>
          <p className="mt-6 max-w-xl text-sm leading-relaxed text-white/60">
            A new world where human vision and AI execution converge. Chapter One is a signal — a broadcast from the future we are building.
          </p>
        </div>
        <div className="grid grid-cols-2 gap-x-8 gap-y-2 border-l border-[#d4af5a]/30 pl-6 font-mono text-[10px] uppercase tracking-[0.25em]">
          <span className="text-white/40">Runtime</span><span style={{ color: "#f5d97a" }}>02:56</span>
          <span className="text-white/40">Aspect</span><span style={{ color: "#f5d97a" }}>2.39 : 1</span>
          <span className="text-white/40">Sound</span><span style={{ color: "#f5d97a" }}>GMCH · 24BIT</span>
          <span className="text-white/40">Voice</span><span style={{ color: "#f5d97a" }}>A. Johnson</span>
          <span className="text-white/40">Chapter</span><span style={{ color: "#f5d97a" }}>01 / V</span>
          <span className="text-white/40">Status</span><span style={{ color: "#6bd97a" }}>◉ ACTIVE</span>
        </div>
      </div>
      <div className="mt-12 h-px w-full" style={{ background: "linear-gradient(90deg, transparent, #d4af5a55, transparent)" }} />
    </section>
  );
}

const STORYBOARD_PANELS: {
  n: string;
  time: string;
  title: string;
  caption: string;
  seek: number;
  accent: string;
  gradient: string;
}[] = [
  { n: "01", time: "0:00 – 0:08", title: "Birmingham, England · 03:17 AM", caption: "A world asleep. One mind refuses to.", seek: 0, accent: "#d4af5a", gradient: "linear-gradient(135deg,#0a1220 0%,#050810 100%)" },
  { n: "02", time: "0:08 – 0:20", title: "Rejection · Persistence", caption: "Years of rejection. Nights of persistence.", seek: 5, accent: "#d4af5a", gradient: "linear-gradient(135deg,#141621 0%,#05070d 100%)" },
  { n: "03", time: "0:20 – 0:35", title: "Every Line of Code", caption: "Every idea. Every dream. Every line of code. They all led here.", seek: 28, accent: "#d4af5a", gradient: "linear-gradient(135deg,#1a1626 0%,#0a0812 100%)" },
  { n: "04", time: "0:35 – 0:50", title: "Another World", caption: "I wasn't looking for a job. I was building another world.", seek: 40, accent: "#f5d97a", gradient: "linear-gradient(135deg,#2a1e12 0%,#0a0810 100%)" },
  { n: "05", time: "0:50 – 1:30", title: "Meet the AIDES", caption: "Not tools. Not bots. A digital workforce.", seek: 80, accent: "#d4af5a", gradient: "linear-gradient(135deg,#12162a 0%,#05070d 100%)" },
  { n: "06", time: "1:30 – 1:50", title: "Where Vision Meets Execution", caption: "A place where human vision and AI execution build the future.", seek: 100, accent: "#4bb8ff", gradient: "linear-gradient(135deg,#0a1a2a 0%,#05080d 100%)" },
  { n: "07", time: "1:50 – 2:20", title: "Different Rooms · One Mission", caption: "AIDES HQ · Venture Farm · GMCH Studio · AEGIS · Mission Control · Builders Hall.", seek: 120, accent: "#a06bff", gradient: "linear-gradient(135deg,#1a1030 0%,#05070d 100%)" },
  { n: "08", time: "2:20 – 2:35", title: "Only Chapter One", caption: "The future isn't waiting to be discovered.", seek: 145, accent: "#f5d97a", gradient: "linear-gradient(135deg,#2a1a12 0%,#0a0810 100%)" },
  { n: "09", time: "2:35 – 2:45", title: "It's Waiting to be Built", caption: "The camera holds. The founder reaches forward.", seek: 150, accent: "#d4af5a", gradient: "linear-gradient(135deg,#1a1220 0%,#05070d 100%)" },
  { n: "10", time: "2:45 – 2:55", title: "Take One Step", caption: "A silhouette. A cape. A choice.", seek: 158, accent: "#d4af5a", gradient: "linear-gradient(135deg,#20180a 0%,#0a0810 100%)" },
  { n: "11", time: "2:55 – 3:00", title: "…and Enter the Portal.", caption: "The doorway opens. Blinding light.", seek: 161, accent: "#f5d97a", gradient: "linear-gradient(135deg,#3a2a12 0%,#0a0810 100%)" },
  { n: "12", time: "3:00", title: "Enter the Portal", caption: "Become a Founding Builder.", seek: 176, accent: "#f5d97a", gradient: "linear-gradient(135deg,#4a3418 0%,#0a0810 100%)" },
];

function StoryboardGrid({ onSeek }: { onSeek: (t: number) => void }) {
  return (
    <section className="mx-auto max-w-[1600px] px-4 pb-12 md:px-8">
      <SectionLabel eyebrow="Storyboard" title="Twelve Beats · One Universe" />
      <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
        {STORYBOARD_PANELS.map((p) => (
          <button
            key={p.n}
            onClick={() => onSeek(p.seek)}
            className="group relative aspect-[4/3] overflow-hidden rounded-lg border border-white/10 text-left transition-all duration-300 hover:border-aurum/50 hover:-translate-y-0.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#f5d97a]"
            style={{ background: p.gradient, boxShadow: "inset 0 1px 0 rgba(255,255,255,0.04)" }}
          >
            {/* particle field */}
            <div
              className="pointer-events-none absolute inset-0 opacity-60"
              style={{
                background: `radial-gradient(circle at 30% 40%, ${p.accent}22 0%, transparent 40%), radial-gradient(circle at 70% 70%, ${p.accent}18 0%, transparent 40%)`,
              }}
            />
            <div
              className="pointer-events-none absolute inset-0 opacity-30 mix-blend-overlay"
              style={{
                backgroundImage:
                  "repeating-linear-gradient(0deg, rgba(255,255,255,0.05) 0px, rgba(255,255,255,0.05) 1px, transparent 1px, transparent 3px)",
              }}
            />
            {/* corner marks */}
            <span className="absolute left-2 top-2 h-3 w-3 border-l border-t" style={{ borderColor: `${p.accent}99` }} />
            <span className="absolute right-2 top-2 h-3 w-3 border-r border-t" style={{ borderColor: `${p.accent}99` }} />
            <span className="absolute left-2 bottom-2 h-3 w-3 border-l border-b" style={{ borderColor: `${p.accent}99` }} />
            <span className="absolute right-2 bottom-2 h-3 w-3 border-r border-b" style={{ borderColor: `${p.accent}99` }} />

            <div className="absolute left-3 top-3 flex items-center gap-2 rounded-sm border border-white/15 bg-black/50 px-2 py-1 text-[10px] font-mono tracking-widest text-white/80">
              <span style={{ color: p.accent }}>{p.n}</span>
              <span className="opacity-40">·</span>
              <span>{p.time}</span>
            </div>

            <div className="absolute inset-x-4 bottom-4">
              <div className="font-display text-sm tracking-[0.15em]" style={{ color: p.accent }}>{p.title.toUpperCase()}</div>
              <div className="mt-1 text-[11px] leading-snug text-white/70">{p.caption}</div>
            </div>

            <div
              className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-100"
              style={{ background: `radial-gradient(600px 200px at 50% 50%, ${p.accent}22, transparent 60%)` }}
            />
          </button>
        ))}
      </div>
    </section>
  );
}

function SectionLabel({ eyebrow, title }: { eyebrow: string; title: string }) {
  return (
    <div className="flex flex-wrap items-baseline justify-between gap-4 border-b border-white/5 pb-6">
      <h2 className="font-display text-3xl font-light uppercase tracking-[0.3em] text-white md:text-5xl">{title}</h2>
      <span className="font-mono text-xs uppercase tracking-[0.3em]" style={{ color: "#4bb8ff" }}>{eyebrow}</span>
    </div>
  );
}

function AidesRoster() {
  return (
    <section className="mx-auto w-full max-w-[1920px] px-4 py-24 md:grid md:grid-cols-2 md:gap-24 md:px-8 md:py-32">
      <div>
        <SectionLabel eyebrow="ROSTER · 06 UNITS" title="The AIDES" />
        <div className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-2">
          {AIDES.map((a, i) => (
            <div key={a.name} className="group border-l pl-5 py-3 transition-all duration-300 hover:translate-x-1" style={{ borderColor: a.color }}>
              <div className="flex items-baseline justify-between">
                <h3 className="font-mono text-lg font-bold uppercase tracking-tight text-white">{a.name}</h3>
                <span className="font-mono text-[10px] tabular-nums text-white/30">UNIT_{String(i + 1).padStart(2, "0")}</span>
              </div>
              <p className="mt-1 text-xs uppercase tracking-[0.25em]" style={{ color: a.color }}>{a.role}</p>
              <p className="mt-3 text-xs leading-relaxed text-white/55">{a.tagline}</p>
              <div className="mt-3 font-mono text-[9px] uppercase tracking-[0.3em] text-white/25">MOTIF · {a.motif}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-24 flex flex-col justify-end md:mt-0">
        <span className="font-mono text-[10px] uppercase tracking-[0.4em] text-white/40">
          Spectral Analysis // Palette
        </span>
        <div className="mt-6 flex h-64 w-full">
          {[
            { hex: "#05070d", label: "OBSIDIAN", fg: "#d4af5a" },
            { hex: "#d4af5a", label: "GOLD", fg: "#05070d" },
            { hex: "#4bb8ff", label: "CYAN", fg: "#05070d" },
            { hex: "#a06bff", label: "NEBULA", fg: "#ffffff" },
            { hex: "#6bd97a", label: "ENERGY", fg: "#05070d" },
          ].map((c) => (
            <div
              key={c.label}
              className="relative flex flex-1 items-center justify-center overflow-hidden transition-[flex] duration-500 hover:flex-[2]"
              style={{ background: c.hex, borderLeft: c.label === "OBSIDIAN" ? "1px solid rgba(255,255,255,0.1)" : "none" }}
            >
              <span
                className="rotate-90 whitespace-nowrap font-mono text-[10px] font-bold uppercase tracking-[0.4em]"
                style={{ color: c.fg }}
              >
                {c.label} · {c.hex}
              </span>
            </div>
          ))}
        </div>
        <p className="mt-6 max-w-md text-xs leading-relaxed text-white/45">
          Obsidian carries the frame. Gold marks the vision. Cyan · Nebula · Energy signal the AIDES at work — each unit a wavelength in the portal spectrum.
        </p>
      </div>
    </section>
  );
}

const PALETTE: { name: string; sub: string; hex: string }[] = [
  { name: "Obsidian", sub: "Black", hex: "#05070d" },
  { name: "Aurum", sub: "Gold", hex: "#d4af5a" },
  { name: "Cyan", sub: "Blue", hex: "#4bb8ff" },
  { name: "Nebula", sub: "Purple", hex: "#a06bff" },
  { name: "Energy", sub: "Green", hex: "#6bd97a" },
  { name: "Light", sub: "Silver", hex: "#cfd7e0" },
];

function VisualLanguage() {
  return (
    <section className="mx-auto max-w-[1600px] px-4 py-12 md:px-8">
      <SectionLabel eyebrow="Visual Language" title="Afrofuturistic · Cinematic · Alive" />
      <div className="mt-6 grid grid-cols-3 gap-2 md:grid-cols-6 md:gap-3">
        {PALETTE.map((c) => (
          <div
            key={c.name}
            className="group relative overflow-hidden rounded-md border border-white/10 bg-black/40 p-3"
          >
            <div
              className="mb-3 h-16 w-full rounded"
              style={{
                background: c.hex === "#05070d" ? "linear-gradient(135deg,#000,#12141c)" : `linear-gradient(135deg, ${c.hex}, ${c.hex}55)`,
                boxShadow: `inset 0 0 30px ${c.hex}44, 0 0 20px ${c.hex}22`,
              }}
            />
            <div className="text-[10px] uppercase tracking-[0.3em] text-white/90">{c.name}</div>
            <div className="text-[9px] uppercase tracking-[0.35em] text-white/40">{c.sub}</div>
            <div className="mt-1 font-mono text-[9px] text-white/40">{c.hex}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function FilmDetails() {
  const items = [
    ["Runtime", "2:30 – 3:00"],
    ["Aspect Ratio", "16 : 9 · Cinema"],
    ["Mood", "Cinematic / Epic / Afrofuturistic"],
    ["Sound", "Original Score · GMCH"],
    ["Voice", "Anthony Johnson · Founder"],
    ["Style Reference", "Black Panther × Avatar × Blade Runner 2049 × TRON Legacy"],
  ];
  return (
    <section className="mx-auto max-w-[1600px] px-4 py-12 md:px-8">
      <SectionLabel eyebrow="Film Details" title="Production Brief" />
      <div
        className="mt-6 grid grid-cols-1 gap-x-8 gap-y-3 rounded-lg border border-white/10 bg-white/[0.02] p-6 md:grid-cols-2 md:p-8"
        style={{ boxShadow: "inset 0 1px 0 rgba(255,255,255,0.04)" }}
      >
        {items.map(([k, v]) => (
          <div key={k} className="flex items-baseline justify-between gap-4 border-b border-white/5 pb-2">
            <span className="text-[10px] uppercase tracking-[0.4em]" style={{ color: "#d4af5a" }}>{k}</span>
            <span className="text-right text-sm text-white/90">{v}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

function ClosingQuote() {
  return (
    <section className="relative mx-auto flex min-h-[80vh] w-full max-w-[1920px] flex-col items-center justify-center px-4 py-24 text-center md:px-8">
      <div className="max-w-5xl">
        <p className="font-display text-4xl font-light leading-[1.05] tracking-tight text-white md:text-6xl lg:text-7xl">
          We don't build <span className="italic" style={{ color: "#d4af5a" }}>the</span> future.
          <br />
          <span className="font-bold uppercase tracking-[0.15em]" style={{ color: "#f5d97a", textShadow: "0 0 60px rgba(245,217,122,0.35)" }}>We build it.</span>
        </p>
        <div className="mt-16 font-mono text-sm tracking-[0.7em] md:tracking-[0.8em]" style={{ color: "#d4af5a", opacity: 0.85 }}>
          #TAGURULABS
        </div>
      </div>
      <div
        className="mt-32 h-16 w-16 rotate-45 border-l border-t"
        style={{ borderColor: "rgba(212,175,90,0.3)" }}
        aria-hidden
      />
      <div className="mt-12 font-mono text-[10px] uppercase tracking-[0.5em] text-white/25">
        END_OF_TRANSMISSION // CH_01 · REV_2.4.0
      </div>
    </section>
  );
}

function EndCard({ onReplay }: { onReplay: () => void }) {
  const [copied, setCopied] = useState(false);
  const [emailOpen, setEmailOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [prophecy, setProphecy] = useState<string | null>(null);
  const [prophecyId, setProphecyId] = useState<string | null>(null);
  const [prophecyLoading, setProphecyLoading] = useState(false);
  const [prophecyError, setProphecyError] = useState<string | null>(null);
  const [typedProphecy, setTypedProphecy] = useState("");
  const [speaking, setSpeaking] = useState(false);
  const [scrollCopied, setScrollCopied] = useState(false);
  const ttsRef = useRef<TtsHandle | null>(null);

  // Hold-to-unlock state.
  const [holdProgress, setHoldProgress] = useState(0);
  const holdRaf = useRef<number | null>(null);
  const holdStart = useRef<number>(0);
  const holdDurationMs = 1400;

  const shareUrl = typeof window !== "undefined" ? window.location.href : "";

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
      logViewerEvent("share");
    } catch { /* noop */ }
  };

  const stopSpeaking = () => {
    ttsRef.current?.stop();
    ttsRef.current = null;
    setSpeaking(false);
  };

  const speak = (text: string) => {
    stopSpeaking();
    setSpeaking(true);
    const h = speakProphecy(text);
    ttsRef.current = h;
    h.done.finally(() => {
      if (ttsRef.current === h) {
        ttsRef.current = null;
        setSpeaking(false);
      }
    });
  };

  // Stop any TTS on unmount.
  useEffect(() => {
    return () => {
      ttsRef.current?.stop();
      ttsRef.current = null;
      if (holdRaf.current) cancelAnimationFrame(holdRaf.current);
    };
  }, []);

  // Auto-speak when the prophecy first arrives.
  useEffect(() => {
    if (prophecy) speak(prophecy);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prophecy]);

  const shareScroll = async () => {
    if (!prophecyId) return;
    try {
      const url = `${window.location.origin}/scroll/${prophecyId}`;
      await navigator.clipboard.writeText(url);
      setScrollCopied(true);
      setTimeout(() => setScrollCopied(false), 1800);
      logViewerEvent("share");
    } catch { /* noop */ }
  };

  // Typewriter reveal for the prophecy once it arrives.
  useEffect(() => {
    if (!prophecy) return;
    setTypedProphecy("");
    let i = 0;
    const id = window.setInterval(() => {
      i += 1;
      setTypedProphecy(prophecy.slice(0, i));
      if (i >= prophecy.length) window.clearInterval(id);
    }, 22);
    return () => window.clearInterval(id);
  }, [prophecy]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = email.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) {
      setError("Enter a valid email.");
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      const { error: insertError } = await supabase.from("access_requests").insert({
        email: trimmed,
        source: "animatic_ch01_endcard",
        user_agent: typeof navigator !== "undefined" ? navigator.userAgent.slice(0, 500) : null,
      });
      if (insertError) throw insertError;
      // Best-effort local cache so a returning visitor sees the confirmed state.
      try {
        const list = JSON.parse(localStorage.getItem("ta_access_requests") ?? "[]");
        list.push({ email: trimmed, at: new Date().toISOString() });
        localStorage.setItem("ta_access_requests", JSON.stringify(list));
      } catch { /* noop */ }
      setSent(true);
      logViewerEvent("request_access");
      // Fire-and-forget prophecy generation.
      setProphecyLoading(true);
      setProphecyError(null);
      generateProphecy({ data: { email: trimmed } })
        .then((result) => {
          if (result.prophecy) {
            setProphecy(result.prophecy);
            setProphecyId(result.id ?? null);
          } else {
            setProphecyError(result.error ?? "The oracle fell silent.");
          }
        })
        .catch((err) => {
          console.error("prophecy call failed", err);
          setProphecyError("The signal broke. Try again.");
        })
        .finally(() => setProphecyLoading(false));
    } catch (err) {
      console.error("access_requests insert failed", err);
      setError("Couldn't log request. Try again in a moment.");
    } finally {
      setSubmitting(false);
    }
  };

  // Hold-to-unlock: charge a ring, then submit when full.
  const beginHold = () => {
    if (submitting) return;
    holdStart.current = performance.now();
    const tick = (now: number) => {
      const p = Math.min(1, (now - holdStart.current) / holdDurationMs);
      setHoldProgress(p);
      if (p >= 1) {
        holdRaf.current = null;
        // Trigger form submit synthetically.
        const fakeEvent = { preventDefault: () => {} } as React.FormEvent;
        void submit(fakeEvent);
        return;
      }
      holdRaf.current = requestAnimationFrame(tick);
    };
    holdRaf.current = requestAnimationFrame(tick);
  };

  const endHold = () => {
    if (holdRaf.current) {
      cancelAnimationFrame(holdRaf.current);
      holdRaf.current = null;
    }
    if (holdProgress < 1) setHoldProgress(0);
  };

  return (
    <div
      className="absolute inset-0 z-20 flex items-center justify-center"
      style={{
        background:
          "radial-gradient(ellipse at center, rgba(4,5,10,0.55) 0%, rgba(4,5,10,0.92) 70%)",
        animation: "ta-fade-in 900ms ease-out both",
      }}
    >
      <div className="mx-auto flex w-full max-w-xl flex-col items-center px-6 text-center">
        <div
          className="font-mono text-[10px] uppercase tracking-[0.5em]"
          style={{ color: "#d4af5a" }}
        >
          CH_01 · TRANSMISSION COMPLETE
        </div>
        <h2
          className="mt-4 text-2xl leading-tight md:text-4xl"
          style={{ fontFamily: "'Space Grotesk', system-ui, sans-serif", color: "#f5efd7" }}
        >
          The portal is open.
        </h2>
        <p className="mt-3 max-w-md text-sm text-white/60">
          Chapter Two drops soon. Request access — you'll be first through the gate.
        </p>

        {!emailOpen && !sent && (
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => setEmailOpen(true)}
              className="group relative inline-flex items-center gap-2 rounded-md px-5 py-2.5 text-[11px] uppercase tracking-[0.3em] transition-all duration-200 active:scale-[0.97] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#f5d97a]"
              style={{ background: "#d4af5a", color: "#05070d" }}
            >
              Request access
            </button>
            <button
              onClick={copy}
              className="inline-flex items-center gap-2 rounded-md border border-white/20 bg-white/[0.03] px-5 py-2.5 text-[11px] uppercase tracking-[0.3em] text-white/80 transition-all duration-200 hover:bg-white/[0.08] active:scale-[0.97]"
            >
              {copied ? "Link copied" : "Share"}
            </button>
            <button
              onClick={() => { logViewerEvent("replay"); onReplay(); }}
              className="inline-flex items-center gap-2 rounded-md border border-white/10 px-5 py-2.5 text-[11px] uppercase tracking-[0.3em] text-white/60 transition-all duration-200 hover:text-white active:scale-[0.97]"
            >
              Replay
            </button>
            <a
              href="/archive"
              className="inline-flex items-center gap-2 rounded-md border border-[#d4af5a]/30 px-5 py-2.5 text-[11px] uppercase tracking-[0.3em] text-[#d4af5a]/90 transition-all duration-200 hover:border-[#f5d97a] hover:text-[#f5d97a] active:scale-[0.97]"
            >
              The Archive ↗
            </a>
          </div>
        )}

        {emailOpen && !sent && (
          <form
            onSubmit={(e) => e.preventDefault()}
            className="mt-8 flex w-full max-w-sm flex-col gap-3"
          >
            <input
              type="email"
              required
              autoFocus
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              maxLength={254}
              placeholder="you@domain.com"
              className="w-full rounded-md border border-white/20 bg-black/40 px-4 py-3 text-center font-mono text-sm text-white placeholder-white/30 outline-none focus:border-[#d4af5a] focus:ring-2 focus:ring-[#d4af5a]/40"
            />
            {error && (
              <div className="font-mono text-[10px] uppercase tracking-[0.3em]" style={{ color: "#ff8b6b" }}>
                {error}
              </div>
            )}
            <div className="mt-2 flex flex-col items-center gap-3">
              <button
                type="button"
                disabled={submitting}
                onMouseDown={beginHold}
                onMouseUp={endHold}
                onMouseLeave={endHold}
                onTouchStart={(e) => { e.preventDefault(); beginHold(); }}
                onTouchEnd={endHold}
                onTouchCancel={endHold}
                onKeyDown={(e) => {
                  if ((e.key === " " || e.key === "Enter") && !e.repeat) beginHold();
                }}
                onKeyUp={(e) => {
                  if (e.key === " " || e.key === "Enter") endHold();
                }}
                className="relative flex h-24 w-24 select-none items-center justify-center rounded-full transition-transform duration-150 active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#f5d97a]"
                style={{
                  background:
                    "radial-gradient(circle at 50% 40%, rgba(245,217,122,0.35) 0%, rgba(212,175,90,0.15) 45%, rgba(4,5,10,0.9) 75%)",
                  boxShadow: `0 0 ${20 + holdProgress * 60}px ${holdProgress * 18}px rgba(212,175,90,${0.15 + holdProgress * 0.55})`,
                }}
                aria-label="Hold to open the gate"
              >
                <svg
                  className="absolute inset-0 -rotate-90"
                  viewBox="0 0 100 100"
                  aria-hidden="true"
                >
                  <circle cx="50" cy="50" r="46" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="3" />
                  <circle
                    cx="50" cy="50" r="46"
                    fill="none"
                    stroke="#f5d97a"
                    strokeWidth="3"
                    strokeLinecap="round"
                    strokeDasharray={2 * Math.PI * 46}
                    strokeDashoffset={2 * Math.PI * 46 * (1 - holdProgress)}
                    style={{ transition: holdProgress === 0 ? "stroke-dashoffset 300ms ease-out" : "none", filter: "drop-shadow(0 0 6px #f5d97a)" }}
                  />
                </svg>
                <span className="relative font-mono text-[9px] uppercase tracking-[0.3em]" style={{ color: "#05070d" }}>
                  {submitting ? "Opening" : holdProgress > 0 ? "Hold" : "Press"}
                </span>
              </button>
              <div className="font-mono text-[9px] uppercase tracking-[0.4em] text-white/50">
                Hold to open the gate
              </div>
              <button
                type="button"
                onClick={() => setEmailOpen(false)}
                disabled={submitting}
                className="text-[10px] uppercase tracking-[0.3em] text-white/40 hover:text-white/80"
              >
                Cancel
              </button>
            </div>
          </form>
        )}

        {sent && (
          <div className="mt-8 flex flex-col items-center gap-2">
            <div
              className="font-mono text-[10px] uppercase tracking-[0.4em]"
              style={{ color: "#6bd97a" }}
            >
              ACCESS REQUEST LOGGED
            </div>
            <p className="text-sm text-white/70">You're on the list. Watch your inbox.</p>

            <div className="mt-6 w-full max-w-md">
              <div
                className="mb-2 font-mono text-[10px] uppercase tracking-[0.4em]"
                style={{ color: "#d4af5a" }}
              >
                {prophecyLoading ? "· ORACLE TRANSMITTING ·" : "· ORACLE TRANSMISSION ·"}
              </div>
              <div
                className="min-h-[5.5rem] rounded-md border px-4 py-4 text-center"
                style={{
                  borderColor: "#d4af5a55",
                  background:
                    "linear-gradient(180deg, rgba(212,175,90,0.06), rgba(4,5,10,0.6))",
                  boxShadow: "0 0 40px -20px rgba(212,175,90,0.6) inset",
                }}
              >
                {prophecyLoading && !prophecy && (
                  <div className="flex items-center justify-center gap-2 py-3 text-white/50">
                    <span
                      className="inline-block h-1.5 w-1.5 rounded-full"
                      style={{ background: "#d4af5a", animation: "ta-pulse 1.2s ease-in-out infinite" }}
                    />
                    <span className="font-mono text-[10px] uppercase tracking-[0.4em]">
                      Forging your prophecy
                    </span>
                  </div>
                )}
                {prophecy && (
                  <p
                    className="whitespace-pre-line text-sm md:text-base leading-relaxed"
                    style={{
                      color: "#f5efd7",
                      fontFamily: "'Space Grotesk', system-ui, sans-serif",
                      letterSpacing: "0.02em",
                    }}
                  >
                    {typedProphecy}
                    {typedProphecy.length < prophecy.length && (
                      <span
                        className="ml-0.5 inline-block h-4 w-[2px] align-middle"
                        style={{ background: "#d4af5a", animation: "ta-flicker 700ms steps(2) infinite" }}
                      />
                    )}
                  </p>
                )}
                {!prophecyLoading && !prophecy && prophecyError && (
                  <p className="text-xs text-white/50">{prophecyError}</p>
                )}
              </div>

              {prophecy && (
                <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                  <button
                    type="button"
                    onClick={() => (speaking ? stopSpeaking() : speak(prophecy))}
                    className="inline-flex items-center gap-2 rounded-md border border-[#d4af5a]/50 bg-[#d4af5a]/10 px-4 py-2 text-[10px] uppercase tracking-[0.3em] text-[#f5d97a] hover:bg-[#d4af5a]/20"
                  >
                    <span
                      className="inline-block h-1.5 w-1.5 rounded-full"
                      style={{
                        background: speaking ? "#f5d97a" : "#d4af5a99",
                        animation: speaking ? "ta-pulse 1.1s ease-in-out infinite" : "none",
                      }}
                    />
                    {speaking ? "Silence the oracle" : "Hear the oracle"}
                  </button>
                  {prophecyId && (
                    <button
                      type="button"
                      onClick={shareScroll}
                      className="inline-flex items-center gap-2 rounded-md border border-white/20 bg-white/[0.03] px-4 py-2 text-[10px] uppercase tracking-[0.3em] text-white/80 hover:bg-white/[0.08]"
                    >
                      {scrollCopied ? "Scroll link copied" : "Share your scroll"}
                    </button>
                  )}
                </div>
              )}
            </div>

            <button
              onClick={() => { logViewerEvent("replay"); onReplay(); }}
              className="mt-3 inline-flex items-center gap-2 rounded-md border border-white/15 px-5 py-2.5 text-[11px] uppercase tracking-[0.3em] text-white/60 hover:text-white"
            >
              Replay
            </button>
          </div>
        )}
      </div>
    </div>
  );
}