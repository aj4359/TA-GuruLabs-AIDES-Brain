export type Aide = {
  name: string;
  role: string;
  color: string;
  motif: string;
  tagline?: string;
};

export const AIDES: Aide[] = [
  { name: "AUREUS", role: "Strategy", color: "#d4af5a", motif: "Brass + Choir · 4 notes", tagline: "Sees the future. Creates the path." },
  { name: "CODEX", role: "Engineering", color: "#4bb8ff", motif: "Electronic Arp · 5 notes", tagline: "Builds systems. Ships solutions." },
  { name: "MOTION", role: "Creative", color: "#a06bff", motif: "Strings + Pads · 6 notes", tagline: "Tells stories. Moves worlds." },
  { name: "SCOUT", role: "Intelligence", color: "#6bd97a", motif: "Glitch + Granular · 7 notes", tagline: "Finds first. Knows more." },
  { name: "CIPHER", role: "Security", color: "#cfd7e0", motif: "Low Brass + FX · 3 notes", tagline: "Protects all. Trust by design." },
  { name: "GMCH", role: "Music & Audio", color: "#ff9a3c", motif: "Rhythm + Bass · 8 notes", tagline: "Creates emotion. Amplifies impact." },
];

export type Scene = {
  id: number;
  start: number; // seconds
  end: number;
  chapter: string;
  emotion: string;
  headline: string;
  caption: string;
  vo?: string;
  dynamics: string;
  energy: number; // 0..1
  score: string;
  sfx: string;
  bg: string; // css background
  accent: string;
  glitch?: boolean;
  portal?: boolean;
  logos?: string[];
  showAides?: boolean;
  silence?: boolean;
  finalHit?: boolean;
  logoReveal?: boolean;
};

export const SCENES: Scene[] = [
  {
    id: 1,
    start: 0,
    end: 5,
    chapter: "00:00 – 00:05",
    emotion: "Curiosity",
    headline: "BLACK SCREEN",
    caption: "A world asleep. One mind refuses to.",
    dynamics: "ppp",
    energy: 0.05,
    score: "Deep space ambience · distant rumble",
    sfx: "Heartbeat 1 (low, wide)",
    bg: "radial-gradient(ellipse at center, #0a0d16 0%, #05070d 60%, #000 100%)",
    accent: "#d4af5a",
  },
  {
    id: 2,
    start: 5,
    end: 10,
    chapter: "00:06 – 00:09",
    emotion: "Loneliness",
    headline: "THOUGHTS. DOUBT. UNCERTAINTY.",
    caption: "Birmingham, England. 03:17 AM.",
    vo: "I built... my own future.",
    dynamics: "ppp → pp",
    energy: 0.1,
    score: "Solo cello whisper",
    sfx: "Heartbeat 2 (stronger) · rain intensifies",
    bg: "radial-gradient(ellipse at 30% 70%, #12141c 0%, #05070d 70%)",
    accent: "#d4af5a",
  },
  {
    id: 3,
    start: 10,
    end: 14,
    chapter: "00:10 – 00:13",
    emotion: "Loneliness",
    headline: "LATE NIGHTS. BIG QUESTIONS.",
    caption: "Years of rejection. Nights of persistence.",
    dynamics: "pp",
    energy: 0.18,
    score: "Solo cello + piano",
    sfx: "Keyboard · breath · paper flip",
    bg: "radial-gradient(ellipse at 60% 40%, #171922 0%, #05070d 70%)",
    accent: "#d4af5a",
  },
  {
    id: 4,
    start: 14,
    end: 18,
    chapter: "00:14 – 00:17",
    emotion: "Hope",
    headline: "THE DECISION",
    caption: "Not alone. With a new kind of team.",
    dynamics: "mp",
    energy: 0.28,
    score: "Low strings, minor chords enter",
    sfx: "Chair · door · footsteps in rain",
    bg: "linear-gradient(180deg, #0a0d16 0%, #14161f 100%)",
    accent: "#d4af5a",
    glitch: true,
  },
  {
    id: 5,
    start: 18,
    end: 28,
    chapter: "00:18 – 00:27",
    emotion: "Hope",
    headline: "I HIRED MYSELF. REGISTERED.",
    caption: "The first move. Self-employed. All in.",
    dynamics: "mp",
    energy: 0.38,
    score: "Strings build · subtle synth pulse",
    sfx: "Paper stamp · cash register · notification",
    bg: "linear-gradient(180deg, #14161f 0%, #1a1d29 100%)",
    accent: "#d4af5a",
    logos: ["REGISTERED"],
  },
  {
    id: 6,
    start: 28,
    end: 40,
    chapter: "00:28 – 00:40",
    emotion: "Hope",
    headline: "WAREHOUSES. WHATEVER PAID THE BILLS.",
    caption: "Every idea. Every line of code. They all led here.",
    dynamics: "mp – mf",
    energy: 0.5,
    score: "Full orchestra introduces",
    sfx: "Typing · UI clicks · industrial ambience",
    bg: "linear-gradient(180deg, #1a1d29 0%, #23273a 100%)",
    accent: "#d4af5a",
  },
  {
    id: 7,
    start: 40,
    end: 70,
    chapter: "00:41 – 01:10",
    emotion: "Discovery",
    headline: "EVERY SPARE HOUR TAUGHT ME SOMETHING.",
    caption: "Every mistake. Every product. A rehearsal for this.",
    vo: "I wasn't building another company...",
    dynamics: "mf – f",
    energy: 0.65,
    score: "Full orchestra + choir · granular pads",
    sfx: "Arp hits · digital atmospheres",
    bg: "linear-gradient(135deg, #1e2338 0%, #2d1e3a 100%)",
    accent: "#a06bff",
    logos: ["GMCH", "AEGIS", "JobGenius"],
    portal: true,
  },
  {
    id: 8,
    start: 70,
    end: 80,
    chapter: "01:11 – 01:20",
    emotion: "Discovery",
    headline: "I STARTED BUILDING AN OPERATING SYSTEM.",
    caption: "A place where human vision and AI execution build the future.",
    dynamics: "f",
    energy: 0.75,
    score: "Full ensemble · driving pulse",
    sfx: "Portal open FX · sub drop",
    bg: "radial-gradient(ellipse at center, #3a2d5a 0%, #1a1330 60%, #05070d 100%)",
    accent: "#f5d97a",
    portal: true,
  },
  {
    id: 9,
    start: 80,
    end: 150,
    chapter: "01:31 – 02:30",
    emotion: "Wonder",
    headline: "MEET THE AIDES",
    caption: "Not tools. Not bots. A digital workforce. Each with a purpose. Together, unstoppable.",
    dynamics: "f",
    energy: 0.85,
    score: "All six themes combine",
    sfx: "AIDES signature hits × 6",
    bg: "linear-gradient(135deg, #0a0d16 0%, #1a1a2e 50%, #0a0d16 100%)",
    accent: "#d4af5a",
    showAides: true,
  },
  {
    id: 10,
    start: 150,
    end: 161,
    chapter: "02:31 – 02:40",
    emotion: "Power",
    headline: "FOR FOUNDERS. FOR BUSINESSES. FOR DREAMERS.",
    caption: "This isn't the end of the story...",
    dynamics: "f – ff",
    energy: 0.92,
    score: "Living city ambience · full ensemble",
    sfx: "Skyline whoosh · sub power",
    bg: "linear-gradient(180deg, #1a1330 0%, #d4af5a22 50%, #05070d 100%)",
    accent: "#f5d97a",
  },
  {
    id: 11,
    start: 161,
    end: 175,
    chapter: "02:41 – 02:55",
    emotion: "Belonging",
    headline: "THE PORTAL OPENS. ENTER THE WORLD.",
    caption: "It's the beginning of yours.",
    dynamics: "ff (break)",
    energy: 0.98,
    score: "Solo piano in space · summation",
    sfx: "Breath · air · huge tail reverb",
    bg: "radial-gradient(ellipse at center, #f5d97a33 0%, #a06bff22 30%, #05070d 80%)",
    accent: "#f5d97a",
    portal: true,
  },
  {
    id: 12,
    start: 175,
    end: 176,
    chapter: "02:56",
    emotion: "Silence",
    headline: "",
    caption: "",
    dynamics: "—",
    energy: 0,
    score: "1 second of silence",
    sfx: "—",
    bg: "#000",
    accent: "#000",
    silence: true,
  },
  {
    id: 13,
    start: 176,
    end: 180,
    chapter: "02:57 – 03:00",
    emotion: "Purpose",
    headline: "ENTER THE PORTAL",
    caption: "The future belongs to builders.",
    dynamics: "fff",
    energy: 1,
    score: "Massive orchestral hit · choir · brass · sub",
    sfx: "Full hit (stinger) · stinger tail",
    bg: "radial-gradient(ellipse at center, #f5d97a55 0%, #d4af5a22 25%, #05070d 80%)",
    accent: "#f5d97a",
    finalHit: true,
    logoReveal: true,
  },
];

export const TOTAL_DURATION = 180;