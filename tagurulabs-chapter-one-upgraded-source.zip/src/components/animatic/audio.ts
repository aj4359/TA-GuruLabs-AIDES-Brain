// Simple Web Audio placeholder cues: heartbeats, portal hits, final stinger.
// Not final score — used to feel timing.

export class AudioCues {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  enabled = false;
  played = new Set<string>();

  // Continuous score bed
  private bedGain: GainNode | null = null;
  private bedFilter: BiquadFilterNode | null = null;
  private bedOscs: OscillatorNode[] = [];
  private bedLFO: OscillatorNode | null = null;
  private bedLFOGain: GainNode | null = null;
  private bedRunning = false;
  private arpTimer: number | null = null;

  init() {
    if (this.ctx) return;
    const AC = (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext);
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = 0.6;
    this.master.connect(this.ctx.destination);
  }

  setEnabled(on: boolean) {
    this.enabled = on;
    if (on) this.init();
    if (this.ctx && this.ctx.state === "suspended") this.ctx.resume();
    if (!on) this.stopBed();
  }

  reset() {
    this.played.clear();
    this.stopBed();
  }

  // ------- Continuous ambient bed -------
  startBed(tonicHz = 55) {
    if (!this.enabled || !this.ctx || !this.master || this.bedRunning) return;
    const ctx = this.ctx;
    const now = ctx.currentTime;

    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 500;
    filter.Q.value = 0.6;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.001, now + 0.05);
    gain.gain.linearRampToValueAtTime(0.12, now + 2.5);

    filter.connect(gain).connect(this.master);

    // Three detuned voices — perfect fifth stack for cinematic openness
    const ratios = [1, 1.5, 2, 3];
    const detunes = [-8, +6, -4, +3];
    const types: OscillatorType[] = ["sawtooth", "triangle", "sine", "sine"];
    ratios.forEach((r, i) => {
      const o = ctx.createOscillator();
      o.type = types[i];
      o.frequency.value = tonicHz * r;
      o.detune.value = detunes[i];
      const g = ctx.createGain();
      g.gain.value = i === 0 ? 0.5 : i === 3 ? 0.08 : 0.2;
      o.connect(g).connect(filter);
      o.start(now);
      this.bedOscs.push(o);
    });

    // Slow filter LFO
    const lfo = ctx.createOscillator();
    lfo.type = "sine";
    lfo.frequency.value = 0.07;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 180;
    lfo.connect(lfoGain).connect(filter.frequency);
    lfo.start(now);

    this.bedFilter = filter;
    this.bedGain = gain;
    this.bedLFO = lfo;
    this.bedLFOGain = lfoGain;
    this.bedRunning = true;
  }

  setBed({ tonicHz, intensity, brightness }: { tonicHz?: number; intensity?: number; brightness?: number }) {
    if (!this.ctx || !this.bedRunning) return;
    const now = this.ctx.currentTime;
    if (typeof tonicHz === "number" && this.bedOscs.length) {
      const ratios = [1, 1.5, 2, 3];
      this.bedOscs.forEach((o, i) => {
        o.frequency.cancelScheduledValues(now);
        o.frequency.linearRampToValueAtTime(tonicHz * ratios[i], now + 1.2);
      });
    }
    if (typeof intensity === "number" && this.bedGain) {
      const target = 0.05 + intensity * 0.22;
      this.bedGain.gain.cancelScheduledValues(now);
      this.bedGain.gain.linearRampToValueAtTime(target, now + 1.5);
    }
    if (typeof brightness === "number" && this.bedFilter) {
      const target = 260 + brightness * 3200;
      this.bedFilter.frequency.cancelScheduledValues(now);
      this.bedFilter.frequency.linearRampToValueAtTime(target, now + 1.5);
    }
  }

  stopBed() {
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    if (this.bedGain) {
      this.bedGain.gain.cancelScheduledValues(now);
      this.bedGain.gain.setValueAtTime(this.bedGain.gain.value, now);
      this.bedGain.gain.linearRampToValueAtTime(0.0001, now + 0.6);
    }
    this.bedOscs.forEach((o) => {
      try { o.stop(now + 0.7); } catch { /* noop */ }
    });
    if (this.bedLFO) {
      try { this.bedLFO.stop(now + 0.7); } catch { /* noop */ }
    }
    this.bedOscs = [];
    this.bedFilter = null;
    this.bedGain = null;
    this.bedLFO = null;
    this.bedLFOGain = null;
    this.bedRunning = false;
    if (this.arpTimer != null) {
      clearInterval(this.arpTimer);
      this.arpTimer = null;
    }
  }

  // Rising cinematic swell
  riser(duration = 4) {
    if (!this.enabled || !this.ctx || !this.master) return;
    const ctx = this.ctx;
    const now = ctx.currentTime;
    // Noise
    const buf = ctx.createBuffer(1, ctx.sampleRate * duration, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1);
    const noise = ctx.createBufferSource();
    noise.buffer = buf;
    const filt = ctx.createBiquadFilter();
    filt.type = "bandpass";
    filt.Q.value = 1.2;
    filt.frequency.setValueAtTime(200, now);
    filt.frequency.exponentialRampToValueAtTime(6000, now + duration);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, now);
    g.gain.linearRampToValueAtTime(0.35, now + duration - 0.2);
    g.gain.linearRampToValueAtTime(0, now + duration);
    noise.connect(filt).connect(g).connect(this.master);
    noise.start(now);
    noise.stop(now + duration + 0.05);

    // Pitched sweep — octave rise
    const o = ctx.createOscillator();
    o.type = "sawtooth";
    const og = ctx.createGain();
    og.gain.setValueAtTime(0, now);
    og.gain.linearRampToValueAtTime(0.12, now + duration - 0.3);
    og.gain.linearRampToValueAtTime(0, now + duration);
    o.frequency.setValueAtTime(110, now);
    o.frequency.exponentialRampToValueAtTime(880, now + duration);
    o.connect(og).connect(this.master);
    o.start(now);
    o.stop(now + duration + 0.05);
  }

  // Arp for the AIDES reveal
  startArp(tonicHz = 220, tempoMs = 260) {
    if (!this.enabled || !this.ctx || !this.master) return;
    if (this.arpTimer != null) return;
    const ratios = [1, 1.2, 1.5, 1.8, 2, 1.8, 1.5, 1.2];
    let step = 0;
    this.arpTimer = window.setInterval(() => {
      if (!this.ctx || !this.master) return;
      const ctx = this.ctx;
      const now = ctx.currentTime;
      const f = tonicHz * ratios[step % ratios.length];
      const o = ctx.createOscillator();
      o.type = "triangle";
      o.frequency.value = f;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0, now);
      g.gain.linearRampToValueAtTime(0.06, now + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.6);
      const filt = ctx.createBiquadFilter();
      filt.type = "lowpass";
      filt.frequency.value = 2400;
      o.connect(filt).connect(g).connect(this.master);
      o.start(now);
      o.stop(now + 0.65);
      step++;
    }, tempoMs);
  }

  stopArp() {
    if (this.arpTimer != null) {
      clearInterval(this.arpTimer);
      this.arpTimer = null;
    }
  }

  heartbeat(strength = 1) {
    if (!this.enabled || !this.ctx || !this.master) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.frequency.setValueAtTime(60, now);
    osc.frequency.exponentialRampToValueAtTime(30, now + 0.15);
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.9 * strength, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
    osc.connect(gain).connect(this.master);
    osc.start(now);
    osc.stop(now + 0.4);
  }

  portalHit() {
    if (!this.enabled || !this.ctx || !this.master) return;
    const now = this.ctx.currentTime;
    // sub
    const sub = this.ctx.createOscillator();
    const subG = this.ctx.createGain();
    sub.frequency.setValueAtTime(80, now);
    sub.frequency.exponentialRampToValueAtTime(25, now + 1.2);
    subG.gain.setValueAtTime(0, now);
    subG.gain.linearRampToValueAtTime(0.9, now + 0.02);
    subG.gain.exponentialRampToValueAtTime(0.001, now + 1.8);
    sub.connect(subG).connect(this.master);
    sub.start(now);
    sub.stop(now + 2);
    // noise sweep
    const buf = this.ctx.createBuffer(1, this.ctx.sampleRate * 1.2, this.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / data.length);
    const noise = this.ctx.createBufferSource();
    noise.buffer = buf;
    const filt = this.ctx.createBiquadFilter();
    filt.type = "bandpass";
    filt.frequency.setValueAtTime(200, now);
    filt.frequency.exponentialRampToValueAtTime(4000, now + 1.0);
    const ng = this.ctx.createGain();
    ng.gain.value = 0.35;
    noise.connect(filt).connect(ng).connect(this.master);
    noise.start(now);
  }

  finalStinger() {
    if (!this.enabled || !this.ctx || !this.master) return;
    const now = this.ctx.currentTime;
    [55, 82.4, 110, 164.8, 220].forEach((f, i) => {
      const o = this.ctx!.createOscillator();
      const g = this.ctx!.createGain();
      o.type = i < 2 ? "sawtooth" : "triangle";
      o.frequency.setValueAtTime(f, now);
      g.gain.setValueAtTime(0, now);
      g.gain.linearRampToValueAtTime(0.35 / (i + 1), now + 0.03);
      g.gain.exponentialRampToValueAtTime(0.001, now + 3.5);
      o.connect(g).connect(this.master!);
      o.start(now);
      o.stop(now + 3.6);
    });
    this.portalHit();
  }

  triggerOnce(key: string, fn: () => void) {
    if (this.played.has(key)) return;
    this.played.add(key);
    fn();
  }
}