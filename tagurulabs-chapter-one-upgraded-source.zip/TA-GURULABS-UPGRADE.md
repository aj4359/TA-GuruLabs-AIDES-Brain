# TA GuruLabs Chapter One Upgrade

This build adds:

- Anthony's `Enter The TA GuruLabs Portal` narration as a synchronized director-track.
- Cinematic portal, AIDES and storyboard artwork integrated into the main animatic.
- Timeline-aware narration play, pause, mute, reset and scrub synchronization.
- Stronger contrast, slow image push-ins, parallax, scan lines, grain and chromatic transitions.
- Accessible reduced-motion behaviour.

## Run locally

```bash
npm install
npm run dev
```

## Publish in Lovable

Import the project or sync these changes to the connected GitHub repository, verify the `/public/media` assets, preview the experience, then publish.

## Security

The exported `.env` file was deliberately removed from this handoff. Reconfigure environment variables securely in Lovable or the deployment platform.
