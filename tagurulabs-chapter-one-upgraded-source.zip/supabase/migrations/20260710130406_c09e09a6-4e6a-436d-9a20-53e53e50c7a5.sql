
CREATE TABLE public.viewer_events (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  session_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  scene_id INTEGER,
  time_s NUMERIC,
  user_agent TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE INDEX viewer_events_session_idx ON public.viewer_events (session_id);
CREATE INDEX viewer_events_created_at_idx ON public.viewer_events (created_at DESC);
CREATE INDEX viewer_events_type_scene_idx ON public.viewer_events (event_type, scene_id);

GRANT INSERT ON public.viewer_events TO anon, authenticated;
GRANT ALL ON public.viewer_events TO service_role;

ALTER TABLE public.viewer_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can log a viewer event"
  ON public.viewer_events
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    session_id IS NOT NULL
    AND char_length(session_id) BETWEEN 8 AND 64
    AND event_type IN ('scene_view','play','pause','complete','replay','share','request_access')
    AND (scene_id IS NULL OR (scene_id BETWEEN 0 AND 999))
    AND (time_s IS NULL OR (time_s >= 0 AND time_s <= 100000))
    AND (user_agent IS NULL OR char_length(user_agent) <= 500)
  );
