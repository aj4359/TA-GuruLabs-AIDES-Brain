ALTER TABLE public.prophecies
  ADD COLUMN IF NOT EXISTS poster_bytes BYTEA,
  ADD COLUMN IF NOT EXISTS poster_content_type TEXT;