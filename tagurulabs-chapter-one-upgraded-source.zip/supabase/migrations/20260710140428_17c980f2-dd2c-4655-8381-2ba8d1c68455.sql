CREATE TABLE public.prophecies (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  prophecy TEXT NOT NULL,
  handle TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.prophecies TO anon;
GRANT SELECT ON public.prophecies TO authenticated;
GRANT ALL ON public.prophecies TO service_role;
ALTER TABLE public.prophecies ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Prophecies are publicly readable" ON public.prophecies FOR SELECT TO anon, authenticated USING (true);
CREATE INDEX idx_prophecies_created_at ON public.prophecies (created_at DESC);